"""Isolation Forest answers whether event behaviour is unusual, not its cause."""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest


ANOMALY_FEATURES = ["mean_frp", "peak_frp", "detections", "mean_confidence", "mean_brightness", "duration_hours", "spatial_spread_km"]


def add_anomaly_scores(events: pd.DataFrame) -> pd.DataFrame:
    result = events.copy()
    if len(result) < 2:
        result["anomaly_score"] = 0.0
        result["anomaly_status"] = "Insufficient events for anomaly analysis"
        result["unusual"] = False
        return result
    features = result[ANOMALY_FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)
    model = IsolationForest(contamination="auto", random_state=42).fit(features)
    result["anomaly_score"] = -model.score_samples(features)
    result["unusual"] = model.predict(features) == -1
    result["anomaly_status"] = np.where(result["unusual"], "Unusual thermal behaviour", "Typical within uploaded events")
    return result
