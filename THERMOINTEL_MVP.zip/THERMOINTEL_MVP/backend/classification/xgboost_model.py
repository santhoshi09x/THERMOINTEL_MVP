"""Supervised XGBoost training interface for future curated event labels."""

from __future__ import annotations

import pandas as pd
from xgboost import XGBClassifier


MODEL_FEATURES = [
    "mean_frp", "peak_frp", "detections", "duration_hours", "persistence_days",
    "mean_confidence", "mean_brightness", "spatial_spread_km", "distance_to_facility_km",
    "anomaly_score",
]
TARGET_COLUMN = "classification"


def train_xgboost_classifier(labelled_events: pd.DataFrame) -> XGBClassifier:
    """Train only on externally curated labels; evaluation belongs to a separate validation workflow."""
    missing = set(MODEL_FEATURES + [TARGET_COLUMN]).difference(labelled_events.columns)
    if missing:
        raise ValueError(f"Labelled event data is missing: {', '.join(sorted(missing))}")
    if labelled_events[TARGET_COLUMN].nunique() < 2:
        raise ValueError("At least two curated target classes are required for XGBoost training.")
    labels = pd.Categorical(labelled_events[TARGET_COLUMN])
    model = XGBClassifier(objective="multi:softprob", eval_metric="mlogloss", random_state=42)
    model.fit(labelled_events[MODEL_FEATURES].fillna(0), labels.codes)
    model.thermointel_class_names = list(labels.categories)
    return model
