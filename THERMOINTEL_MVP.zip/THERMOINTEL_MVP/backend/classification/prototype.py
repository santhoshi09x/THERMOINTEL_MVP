"""Transparent fallback classification used only until curated labels exist."""

from __future__ import annotations

import numpy as np
import pandas as pd


def add_prototype_classification(events: pd.DataFrame) -> pd.DataFrame:
    result = events.copy()
    industrial_fire = result["near_industrial"] & result["unusual"] & (result["peak_frp"] >= 60)
    persistent_source = result["near_industrial"] & (result["persistence_days"] >= 3) & ~industrial_fire
    result["classification"] = np.select(
        [industrial_fire, persistent_source],
        ["Potential Industrial Fire", "Persistent Industrial Thermal Source"],
        default="Natural / Other Thermal Event",
    )
    result["classification_method"] = "Transparent prototype rules (no labelled event model loaded)"
    result["prototype_score"] = (
        0.30 * np.clip(result["mean_confidence"] / 100, 0, 1)
        + 0.25 * np.clip(result["peak_frp"] / 120, 0, 1)
        + 0.25 * result["near_industrial"].astype(float)
        + 0.20 * result["unusual"].astype(float)
    ) * 100
    return result
