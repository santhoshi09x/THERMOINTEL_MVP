"""One callable pipeline used by the Streamlit dashboard and future API layer."""

from __future__ import annotations

import pandas as pd

from backend.anomaly_detection import add_anomaly_scores
from backend.classification import add_prototype_classification
from backend.event_formation import form_events
from backend.geospatial import enrich_with_facilities, load_facilities
from backend.ingestion import normalise_firms_dataframe


def process_firms(raw_detections: pd.DataFrame, facility_source=None) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Process a FIRMS upload into GIS-ready events with explicit prototype status."""
    detections = normalise_firms_dataframe(raw_detections)
    events, detections = form_events(detections)
    facilities = load_facilities(facility_source)
    events = enrich_with_facilities(events, facilities)
    events = add_anomaly_scores(events)
    events = add_prototype_classification(events)
    return events, detections, facilities
