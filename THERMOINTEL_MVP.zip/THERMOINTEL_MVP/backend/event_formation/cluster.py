"""HDBSCAN event formation and event-level thermal feature generation."""

from __future__ import annotations

import numpy as np
import pandas as pd


def _haversine_km(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = (np.radians(value) for value in (lat1, lon1, lat2, lon2))
    dlat, dlon = lat2 - lat1, lon2 - lon1
    value = np.sin(dlat / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2) ** 2
    return 6371.0088 * 2 * np.arcsin(np.sqrt(value))


def _cluster_labels(detections: pd.DataFrame) -> np.ndarray:
    """Cluster locations only; HDBSCAN's role is event formation, not classing."""
    if len(detections) < 3:
        return np.full(len(detections), -1, dtype=int)
    coords = detections[["latitude", "longitude"]].to_numpy(dtype=float)
    try:
        import hdbscan

        return hdbscan.HDBSCAN(min_cluster_size=3, min_samples=2).fit_predict(coords)
    except ImportError as error:
        raise RuntimeError("hdbscan is required for thermal event formation.") from error


def form_events(detections: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Group detections into thermal events and calculate event-level features."""
    enriched = detections.copy()
    labels = _cluster_labels(enriched)
    enriched["cluster_label"] = labels
    noise = enriched["cluster_label"].eq(-1)
    enriched.loc[noise, "cluster_label"] = np.arange(100000, 100000 + noise.sum())
    enriched["event_id"] = enriched["cluster_label"].map(lambda value: f"EVT-{int(value):05d}")

    records = []
    for event_id, group in enriched.groupby("event_id", sort=True):
        centroid_lat, centroid_lon = group["latitude"].mean(), group["longitude"].mean()
        distances = _haversine_km(group["latitude"], group["longitude"], centroid_lat, centroid_lon)
        timestamps = group["event_timestamp"].dropna()
        duration_hours = ((timestamps.max() - timestamps.min()).total_seconds() / 3600) if len(timestamps) > 1 else 0.0
        records.append({
            "event_id": event_id,
            "latitude": centroid_lat,
            "longitude": centroid_lon,
            "detections": len(group),
            "duration_hours": duration_hours,
            "persistence_days": int(timestamps.dt.date.nunique()) if not timestamps.empty else 0,
            "mean_frp": group["frp"].mean(),
            "peak_frp": group["frp"].max(),
            "mean_confidence": group["confidence"].mean(),
            "mean_brightness": group["brightness"].mean(),
            "peak_brightness": group["brightness"].max(),
            "brightness_std": group["brightness"].std(ddof=0),
            "spatial_spread_km": float(np.max(distances)) if len(distances) else 0.0,
            "event_history": group.sort_values("event_timestamp")["event_timestamp"].dropna().dt.strftime("%Y-%m-%d %H:%M").tolist(),
        })
    return pd.DataFrame(records), enriched
