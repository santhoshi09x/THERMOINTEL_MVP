"""THERMOINTEL's reusable, offline-first processing pipeline."""
