"""Validation and normalisation for FIRMS-style CSV uploads."""

from __future__ import annotations

import pandas as pd


FIELD_ALIASES = {
    "latitude": "latitude",
    "lat": "latitude",
    "longitude": "longitude",
    "lon": "longitude",
    "lng": "longitude",
    "confidence": "confidence",
    "conf": "confidence",
    "frp": "frp",
    "brightness": "brightness",
    "bright_ti4": "brightness",
    "bright_ti5": "brightness",
    "acq_date": "acq_date",
    "date": "acq_date",
    "acq_time": "acq_time",
    "time": "acq_time",
}


def normalise_firms_dataframe(raw: pd.DataFrame) -> pd.DataFrame:
    """Return a validated FIRMS-compatible detection table.

    NASA FIRMS exports vary by satellite and product. Missing optional thermal
    fields are retained as zero so downstream event formation can still run.
    """
    rename = {column: FIELD_ALIASES[column.lower().strip()]
              for column in raw.columns if column.lower().strip() in FIELD_ALIASES}
    detections = raw.rename(columns=rename).copy()

    required = {"latitude", "longitude"}
    missing = required.difference(detections.columns)
    if missing:
        raise ValueError("CSV must contain latitude and longitude columns.")

    for field in ("latitude", "longitude", "confidence", "frp", "brightness"):
        if field not in detections:
            detections[field] = 0
        detections[field] = pd.to_numeric(detections[field], errors="coerce")

    detections = detections.dropna(subset=["latitude", "longitude"]).copy()
    if detections.empty:
        raise ValueError("No rows contain valid latitude and longitude values.")

    if "acq_date" not in detections:
        detections["acq_date"] = pd.NaT
    detections["acq_date"] = pd.to_datetime(detections["acq_date"], errors="coerce")

    if "acq_time" not in detections:
        detections["acq_time"] = "0000"
    time_text = detections["acq_time"].fillna("0000").astype(str).str.replace(r"\.0$", "", regex=True).str.zfill(4)
    time_text = time_text.where(time_text.str.fullmatch(r"[0-2][0-9][0-5][0-9]"), "0000")
    detections["event_timestamp"] = pd.to_datetime(
        detections["acq_date"].dt.strftime("%Y-%m-%d") + " " + time_text,
        errors="coerce",
    )
    return detections.reset_index(drop=True)
