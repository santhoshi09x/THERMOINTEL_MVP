"""Offline facility context enrichment from a user CSV or bundled DEMO data."""

from __future__ import annotations

from pathlib import Path
import json

import numpy as np
import pandas as pd


DEFAULT_FACILITIES = Path(__file__).resolve().parents[1] / "data" / "demo_facilities.csv"


def load_facilities(source=None) -> pd.DataFrame:
    source = source or DEFAULT_FACILITIES
    source_name = getattr(source, "name", str(source)).lower()
    if source_name.endswith((".geojson", ".json")):
        document = json.load(source) if hasattr(source, "read") else json.loads(Path(source).read_text(encoding="utf-8"))
        records = []
        for feature in document.get("features", []):
            geometry = feature.get("geometry") or {}
            coordinates = geometry.get("coordinates", [])
            if geometry.get("type") != "Point" or len(coordinates) < 2:
                continue
            properties = feature.get("properties") or {}
            records.append({
                "facility": properties.get("facility") or properties.get("name") or "Unnamed facility",
                "latitude": coordinates[1],
                "longitude": coordinates[0],
                "facility_type": properties.get("facility_type") or properties.get("type") or "Unknown",
            })
        facilities = pd.DataFrame(records, columns=["facility", "latitude", "longitude", "facility_type"])
    else:
        facilities = pd.read_csv(source)
    required = {"facility", "latitude", "longitude", "facility_type"}
    if not required.issubset(facilities.columns):
        raise ValueError("Facility data needs facility, latitude, longitude, and facility_type columns.")
    return facilities.dropna(subset=["latitude", "longitude"]).copy()


def _haversine_km(latitude, longitude, facility_latitudes, facility_longitudes):
    lat1, lon1 = np.radians(latitude), np.radians(longitude)
    lat2, lon2 = np.radians(facility_latitudes), np.radians(facility_longitudes)
    value = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 6371.0088 * 2 * np.arcsin(np.sqrt(value))


def enrich_with_facilities(events: pd.DataFrame, facilities: pd.DataFrame, industrial_radius_km: float = 5.0) -> pd.DataFrame:
    """Add nearest facility context without assuming facility coverage is complete."""
    result = events.copy()
    if facilities.empty:
        result["nearest_facility"] = "No facility data available"
        result["facility_type"] = "Unknown"
        result["distance_to_facility_km"] = np.nan
        result["near_industrial"] = False
        return result

    facility_lats = facilities["latitude"].to_numpy(float)
    facility_lons = facilities["longitude"].to_numpy(float)
    nearest_indices, nearest_distances = [], []
    for event in result.itertuples():
        distances = _haversine_km(event.latitude, event.longitude, facility_lats, facility_lons)
        index = int(np.argmin(distances))
        nearest_indices.append(index)
        nearest_distances.append(float(distances[index]))
    nearest = facilities.iloc[nearest_indices].reset_index(drop=True)
    result["nearest_facility"] = nearest["facility"]
    result["facility_type"] = nearest["facility_type"]
    result["distance_to_facility_km"] = nearest_distances
    result["near_industrial"] = result["distance_to_facility_km"] <= industrial_radius_km
    return result
