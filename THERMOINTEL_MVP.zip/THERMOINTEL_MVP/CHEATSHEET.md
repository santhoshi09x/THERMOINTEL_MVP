# 🚀 THERMOINTEL MVP - Quick Reference Cheatsheet

## ⚡ Launch Commands

```bash
# Enhanced Multi-Page Dashboard (Recommended)
streamlit run app.py

# Legacy Single-Page Dashboard
streamlit run streamlit_app.py

# Verify Installation
python verify_installation.py

# Windows Quick Launch
run_enhanced.bat
```

---

## 📊 Dashboard Pages

| Icon | Page | Purpose | Key Features |
|------|------|---------|--------------|
| 📊 | **Dashboard** | Overview | Map, metrics, alerts, charts |
| 🏭 | **Facility Analysis** | Facility insights | Risk ranking, trends, heatmaps |
| 📈 | **Event Analysis** | Clustering | 3D plots, stats, temporal, spatial |
| 💡 | **Insights & Alerts** | AI recommendations | Priority alerts, predictions |
| 📄 | **Reports** | Export | CSV, Excel, JSON reports |

---

## 🎨 Color Codes

### Event Classification
- 🔴 **Red** - Potential Industrial Fire
- 🟠 **Orange** - Persistent Thermal Source
- 🔵 **Blue** - Natural / Other Event

### Risk Levels
- 🔴 **Critical** - Immediate action (>70)
- 🟡 **High** - Monitor closely (40-70)
- 🟠 **Medium** - Routine check (20-40)
- 🟢 **Low** - Normal (<20)

### Alert Priority
- 🔴 **Critical** - Industrial fire + close + high FRP
- 🟡 **Warning** - Anomaly + near facility
- 🟢 **Normal** - Persistent routine operations

---

## 📏 Key Metrics

| Metric | Unit | Typical Range | Meaning |
|--------|------|---------------|---------|
| **FRP** | MW | 10-1000 | Fire intensity |
| **Duration** | hours | 0-72 | Event length |
| **Persistence** | days | 1-30 | Multi-day activity |
| **Distance** | km | 0-50 | To nearest facility |
| **Spatial Spread** | km | 0-10 | Geographic extent |
| **Anomaly Score** | 0-1 | 0.1-0.9 | Lower = more anomalous |
| **Confidence** | % | 0-100 | Classification certainty |

---

## 🔍 Quick Actions

### Upload & Process
1. Click "Browse files" (sidebar)
2. Select FIRMS CSV
3. Click "🔄 Process Data"
4. Wait for ✅ success

### View Critical Alerts
1. Go to **Dashboard** page
2. Scroll to 🚨 section
3. Read red alert cards

### Analyze Facility
1. Go to **Facility Analysis**
2. Select from dropdown
3. Review charts

### Generate Report
1. Go to **Reports**
2. Configure settings
3. Click "Export Full Report"
4. Download file

---

## 📊 Chart Types by Page

### Dashboard Page
- Metric cards (4)
- Interactive map
- Pie chart (classification)
- Histogram (FRP)
- Box plot (duration)
- Scatter plot (distance vs FRP)

### Facility Analysis Page
- Bar chart (classification)
- Pie chart (anomaly)
- Histogram (FRP, duration)
- Line chart (daily trend)
- Heatmap (spatial density)
- Bar chart (top facilities)
- Scatter plot (distance vs FRP)

### Event Analysis Page
- 3D scatter (lat/lon/FRP)
- 2D scatter (duration vs FRP)
- Dendrogram (hierarchical)
- Histogram + box (distributions)
- Correlation heatmap
- Line chart (daily)
- Bar chart (hourly, weekly)
- Day-hour heatmap

### Insights Page
- Pie chart (risk distribution)
- Alert cards (3 types)
- Tables (facilities, metrics)
- Box plots (FRP, distance)

### Reports Page
- All preview charts
- Summary tables
- Risk matrix

---

## 🎯 Common Workflows

### Daily Monitoring
```
Upload data → Process → Dashboard → Check alerts → Export critical
```

### Facility Audit
```
Upload data → Process → Facility Analysis → Select facility → 
Review charts → Export report
```

### Incident Investigation
```
Upload data → Process → Event Analysis → Apply filters → 
Review clustering → Check temporal → Export details
```

### Compliance Report
```
Upload data → Process → Reports → Configure → Preview → 
Export Excel → Distribute
```

---

## 🔧 Troubleshooting

| Problem | Solution |
|---------|----------|
| Command not found | `pip install streamlit` |
| Port in use | `streamlit run app.py --server.port 8502` |
| Map not showing | Check internet connection |
| Processing error | Verify CSV format |
| Export fails | `pip install openpyxl` |
| Slow performance | Use filters, process once |

---

## 📥 Export Formats

| Format | Best For | Contains |
|--------|----------|----------|
| **CSV** | Data analysis | Single table, raw data |
| **Excel** | Stakeholders | Multi-sheet, formatted |
| **JSON** | API/systems | Structured, machine-readable |

---

## 🎓 Learning Path

### Beginner (30 min)
1. Read **QUICKSTART.md** (5 min)
2. Run **verify_installation.py** (2 min)
3. Launch dashboard (1 min)
4. Upload demo data (2 min)
5. Explore each page (20 min)

### Intermediate (2 hours)
1. Read **USER_GUIDE.md** sections (60 min)
2. Try all workflows (30 min)
3. Generate reports (15 min)
4. Explore filters (15 min)

### Advanced (4 hours)
1. Read full **USER_GUIDE.md** (90 min)
2. Review **FEATURES.md** (30 min)
3. Examine code (60 min)
4. Customize visualizations (60 min)

---

## 🔑 Keyboard Shortcuts

| Key | Action |
|-----|--------|
| `Ctrl + R` | Rerun dashboard |
| `C` | Clear cache |
| `Esc` | Close modals |
| Browser native | Zoom charts (Ctrl + scroll) |

---

## 📁 Important Files

| File | Purpose |
|------|---------|
| `app.py` | Main dashboard |
| `requirements.txt` | Dependencies |
| `USER_GUIDE.md` | Full documentation |
| `QUICKSTART.md` | Quick start |
| `PROJECT_SUMMARY.md` | Project overview |
| `verify_installation.py` | Check setup |

---

## 🌐 URLs

| Service | URL |
|---------|-----|
| Dashboard | http://localhost:8501 |
| Alternate port | http://localhost:8502 |

---

## 💡 Pro Tips

✅ Upload facility data for better context  
✅ Use filters in Event Analysis for focus  
✅ Export reports regularly for records  
✅ Check multiple views for verification  
✅ Review anomalies for unusual patterns  
✅ Process data once per session  
✅ Use modern browser (Chrome/Firefox)  
✅ Close other tabs for performance  

---

## 📊 Filter Options

### Event Analysis Filters
- **Classification:** Multi-select
- **Anomaly Status:** Multi-select
- **Minimum FRP:** Slider

### Report Filters
- **Classification:** Multi-select
- **Facilities:** Multi-select
- **Anomalies Only:** Toggle

---

## 🎯 Success Indicators

| Indicator | Meaning |
|-----------|---------|
| ✅ Green checkmark | Success |
| ❌ Red X | Error |
| ⚠️ Warning triangle | Caution |
| ℹ️ Info icon | Information |
| 🔴 Red dot | Critical |
| 🟡 Yellow dot | Warning |
| 🟢 Green dot | Normal |

---

## 📞 Getting Help

1. **Check Documentation:**
   - QUICKSTART.md
   - USER_GUIDE.md
   - FEATURES.md

2. **Run Verification:**
   ```bash
   python verify_installation.py
   ```

3. **Check Browser Console:**
   - F12 → Console tab
   - Look for error messages

4. **Review Logs:**
   - Terminal output
   - Error messages

---

## 🎉 Quick Wins

### First 5 Minutes
- [x] Install dependencies
- [x] Launch dashboard
- [x] Upload sample data
- [x] View map
- [x] Check metrics

### First 15 Minutes
- [x] All 5 pages visited
- [x] Facility selected
- [x] Filters applied
- [x] Report generated
- [x] Data exported

### First Hour
- [x] All features explored
- [x] Multiple datasets tested
- [x] Reports customized
- [x] Workflows practiced
- [x] Documentation reviewed

---

**Print this cheatsheet for quick reference! 🖨️**

---

**Version:** 1.0 Enhanced  
**Last Updated:** 2024  
**Format:** Quick Reference Card
