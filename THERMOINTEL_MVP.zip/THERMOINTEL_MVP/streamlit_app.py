import pandas as pd
import folium
import streamlit as st
from streamlit_folium import st_folium

from backend.pipeline import process_firms


st.set_page_config(page_title="THERMOINTEL MVP", layout="wide")
st.title("THERMOINTEL")
st.caption("Event-Centric AI for Industrial Thermal Intelligence | Offline-capable MVP")


@st.cache_data
def load_demo() -> pd.DataFrame:
    return pd.read_csv("sample_firms.csv")


uploaded = st.file_uploader("Upload NASA FIRMS CSV", type=["csv"])
facility_upload = st.file_uploader(
    "Upload facility context (optional)",
    type=["csv", "geojson", "json"],
    help="CSV columns: facility, latitude, longitude, facility_type. GeoJSON Point features may use name/type properties.",
)

raw_detections = pd.read_csv(uploaded) if uploaded else load_demo()
try:
    events, detections, facilities = process_firms(raw_detections, facility_upload)
except (ValueError, RuntimeError, pd.errors.ParserError) as error:
    st.error(str(error))
    st.stop()

if uploaded is None:
    st.warning("DEMO DATA: the bundled FIRMS-like detections and facility context are synthetic demonstration data.")
elif facility_upload is None:
    st.info("Facility context uses bundled DEMO DATA. Upload a facility CSV to replace it; missing OSM coverage never stops processing.")

c1, c2, c3, c4 = st.columns(4)
c1.metric("Thermal detections", len(detections))
c2.metric("Thermal events", len(events))
c3.metric("Potential industrial fires", int(events["classification"].eq("Potential Industrial Fire").sum()))
c4.metric("Persistent sources", int(events["classification"].eq("Persistent Industrial Thermal Source").sum()))

st.subheader("THERMOINTEL Event Map")
event_center = [events["latitude"].mean(), events["longitude"].mean()]
event_map = folium.Map(location=event_center, zoom_start=7)
colors = {
    "Potential Industrial Fire": "red",
    "Persistent Industrial Thermal Source": "orange",
    "Natural / Other Thermal Event": "blue",
}
for event in events.itertuples():
    history = "<br>".join(event.event_history) if event.event_history else "No valid acquisition time"
    popup = (
        f"<b>{event.event_id}</b><br>"
        f"Classification: {event.classification}<br>"
        f"Prototype score: {event.prototype_score:.0f}%<br>"
        f"Method: transparent rules, not validated XGBoost<br>"
        f"Detections: {event.detections}<br>"
        f"Duration: {event.duration_hours:.1f} h across {event.persistence_days} day(s)<br>"
        f"Peak FRP: {event.peak_frp:.1f}<br>"
        f"Anomaly: {event.anomaly_status} ({event.anomaly_score:.3f})<br>"
        f"Nearest facility: {event.nearest_facility} ({event.facility_type})<br>"
        f"Distance: {event.distance_to_facility_km:.2f} km<br>"
        f"History:<br>{history}"
    )
    folium.CircleMarker(
        [event.latitude, event.longitude],
        radius=8,
        color=colors[event.classification],
        fill=True,
        fill_opacity=0.8,
        popup=folium.Popup(popup, max_width=340),
    ).add_to(event_map)
for facility in facilities.itertuples():
    folium.Marker(
        [facility.latitude, facility.longitude],
        tooltip=f"{facility.facility} ({facility.facility_type})",
        icon=folium.Icon(color="gray", icon="industry", prefix="fa"),
    ).add_to(event_map)
st_folium(event_map, width=None, height=500)

st.subheader("Event Analysis")
st.dataframe(
    events[[
        "event_id", "latitude", "longitude", "detections", "duration_hours", "persistence_days",
        "peak_frp", "spatial_spread_km", "nearest_facility", "facility_type",
        "distance_to_facility_km", "anomaly_status", "anomaly_score", "classification", "prototype_score",
    ]],
    use_container_width=True,
)

with st.expander("Pipeline and model status"):
    st.markdown("""
    - **Event formation:** HDBSCAN groups related thermal detections; it is not a classifier.
    - **Anomaly detection:** Isolation Forest marks behaviour unusual relative to the current upload; it does not determine cause.
    - **Classification:** Current results use transparent prototype rules because NASA FIRMS has no industrial/natural ground-truth labels.
    - **XGBoost:** A training interface is available in `backend/classification/xgboost_model.py` for a curated labelled event dataset. No accuracy is claimed.
    - **CNN:** Satellite image feature extraction is intentionally unimplemented until suitable image patches are supplied; no CNN predictions are fabricated.
    - **Facility coverage:** The offline facility file is contextual evidence, not a complete OSM inventory.
    """)
