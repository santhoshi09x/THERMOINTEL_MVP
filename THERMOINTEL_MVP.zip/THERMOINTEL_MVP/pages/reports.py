"""Professional Report Generation and Export."""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime
import io


def show():
    """Display reports page."""
    events = st.session_state.events
    detections = st.session_state.detections
    facilities = st.session_state.facilities
    
    st.markdown('<div class="main-header">📄 REPORTS & EXPORTS</div>', unsafe_allow_html=True)
    
    st.markdown("""
    Generate comprehensive reports for analysis, documentation, and stakeholder communication.
    Reports include event summaries, facility analysis, risk assessments, and visualizations.
    """)
    
    st.markdown("---")
    
    # Report Configuration
    st.subheader("📝 Report Configuration")
    
    col1, col2 = st.columns(2)
    
    with col1:
        report_title = st.text_input("Report Title", "ThermoIntel Analysis Report")
        report_author = st.text_input("Author/Organization", "ThermoIntel MVP")
        
    with col2:
        report_date = st.date_input("Report Date", datetime.now())
        report_type = st.selectbox(
            "Report Type",
            ["Executive Summary", "Detailed Analysis", "Facility-Specific", "Custom"]
        )
    
    # Filters
    st.markdown("### 🎯 Data Filters")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        classification_filter = st.multiselect(
            "Event Classification",
            options=events["classification"].unique().tolist(),
            default=events["classification"].unique().tolist()
        )
    
    with col2:
        facility_filter = st.multiselect(
            "Facilities",
            options=["All"] + sorted(events["nearest_facility"].unique().tolist()),
            default=["All"]
        )
    
    with col3:
        include_anomalies_only = st.checkbox("Anomalies Only", value=False)
    
    # Apply filters
    filtered_events = events[events["classification"].isin(classification_filter)]
    
    if "All" not in facility_filter:
        filtered_events = filtered_events[filtered_events["nearest_facility"].isin(facility_filter)]
    
    if include_anomalies_only:
        filtered_events = filtered_events[filtered_events["anomaly_status"] == "Anomaly"]
    
    st.info(f"Report will include {len(filtered_events)} of {len(events)} events")
    
    st.markdown("---")
    
    # Report Preview
    st.subheader("📊 Report Preview")
    
    # Executive Summary Section
    with st.expander("📋 Executive Summary", expanded=True):
        st.markdown(f"### {report_title}")
        st.markdown(f"**Date:** {report_date.strftime('%B %d, %Y')}")
        st.markdown(f"**Prepared by:** {report_author}")
        st.markdown("---")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Events", len(filtered_events))
        with col2:
            industrial_fires = len(filtered_events[filtered_events["classification"] == "Potential Industrial Fire"])
            st.metric("Industrial Fires", industrial_fires)
        with col3:
            anomalies = len(filtered_events[filtered_events["anomaly_status"] == "Anomaly"])
            st.metric("Anomalies", anomalies)
        with col4:
            high_risk = len(filtered_events[
                (filtered_events["classification"] == "Potential Industrial Fire") &
                (filtered_events["distance_to_facility_km"] <= 2)
            ])
            st.metric("High Risk", high_risk)
        
        st.markdown("#### Key Findings")
        
        findings = []
        
        # Finding 1: Most active facilities
        top_facility = filtered_events["nearest_facility"].value_counts().idxmax()
        top_facility_count = filtered_events["nearest_facility"].value_counts().max()
        findings.append(f"• **Most Active Facility:** {top_facility} with {top_facility_count} events")
        
        # Finding 2: Average FRP
        avg_frp = filtered_events["peak_frp"].mean()
        findings.append(f"• **Average Peak FRP:** {avg_frp:.1f} MW across all events")
        
        # Finding 3: Proximity analysis
        within_2km = len(filtered_events[filtered_events["distance_to_facility_km"] <= 2])
        pct_close = (within_2km / len(filtered_events)) * 100 if len(filtered_events) > 0 else 0
        findings.append(f"• **Facility Proximity:** {within_2km} events ({pct_close:.1f}%) within 2 km of facilities")
        
        # Finding 4: Duration
        avg_duration = filtered_events["duration_hours"].mean()
        findings.append(f"• **Average Event Duration:** {avg_duration:.1f} hours")
        
        # Finding 5: Anomaly rate
        anomaly_rate = (anomalies / len(filtered_events)) * 100 if len(filtered_events) > 0 else 0
        findings.append(f"• **Anomaly Rate:** {anomaly_rate:.1f}% of events flagged as anomalous")
        
        for finding in findings:
            st.markdown(finding)
    
    # Facility Analysis Section
    with st.expander("🏭 Facility Analysis"):
        # Calculate facility statistics
        facility_stats = []
        for facility in facilities.itertuples():
            fac_events = filtered_events[filtered_events["nearest_facility"] == facility.facility]
            if len(fac_events) > 0:
                facility_stats.append({
                    "Facility": facility.facility,
                    "Type": facility.facility_type,
                    "Events": len(fac_events),
                    "Industrial Fires": len(fac_events[fac_events["classification"] == "Potential Industrial Fire"]),
                    "Avg Peak FRP": fac_events["peak_frp"].mean(),
                    "Max Peak FRP": fac_events["peak_frp"].max(),
                    "Avg Distance": fac_events["distance_to_facility_km"].mean(),
                    "Anomalies": len(fac_events[fac_events["anomaly_status"] == "Anomaly"])
                })
        
        if facility_stats:
            facility_df = pd.DataFrame(facility_stats).sort_values("Events", ascending=False)
            st.dataframe(facility_df.round(2), use_container_width=True, height=400)
            
            # Top 5 facilities chart
            st.markdown("**Top 10 Facilities by Event Count**")
            top_10 = facility_df.head(10)
            fig_fac = px.bar(
                top_10,
                x="Events",
                y="Facility",
                orientation="h",
                color="Industrial Fires",
                color_continuous_scale="Reds",
                labels={"Events": "Number of Events", "Industrial Fires": "Industrial Fires"}
            )
            fig_fac.update_layout(height=400)
            st.plotly_chart(fig_fac, use_container_width=True)
    
    # Event Classification Section
    with st.expander("📊 Event Classification Analysis"):
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Classification Distribution**")
            class_counts = filtered_events["classification"].value_counts()
            fig_class = px.pie(
                values=class_counts.values,
                names=class_counts.index,
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                hole=0.4
            )
            fig_class.update_layout(height=350)
            st.plotly_chart(fig_class, use_container_width=True)
            
            # Classification statistics
            for classification in class_counts.index:
                class_events = filtered_events[filtered_events["classification"] == classification]
                st.markdown(f"**{classification}**")
                st.markdown(f"- Count: {len(class_events)}")
                st.markdown(f"- Avg FRP: {class_events['peak_frp'].mean():.1f} MW")
                st.markdown(f"- Avg Duration: {class_events['duration_hours'].mean():.1f} hours")
                st.markdown("---")
        
        with col2:
            st.markdown("**FRP Distribution by Classification**")
            fig_frp_box = px.box(
                filtered_events,
                x="classification",
                y="peak_frp",
                color="classification",
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={"peak_frp": "Peak FRP (MW)", "classification": "Classification"}
            )
            fig_frp_box.update_layout(height=350, showlegend=False)
            st.plotly_chart(fig_frp_box, use_container_width=True)
            
            st.markdown("**Duration Distribution**")
            fig_duration = px.histogram(
                filtered_events,
                x="duration_hours",
                color="classification",
                nbins=20,
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={"duration_hours": "Duration (hours)"}
            )
            fig_duration.update_layout(height=300)
            st.plotly_chart(fig_duration, use_container_width=True)
    
    # Risk Assessment Section
    with st.expander("⚠️ Risk Assessment"):
        st.markdown("### Risk Matrix")
        
        # Categorize events by risk
        risk_categories = {
            "Critical": [],
            "High": [],
            "Medium": [],
            "Low": []
        }
        
        for _, event in filtered_events.iterrows():
            if (event["classification"] == "Potential Industrial Fire" and 
                event["distance_to_facility_km"] <= 2 and 
                event["peak_frp"] > filtered_events["peak_frp"].quantile(0.75)):
                risk_categories["Critical"].append(event)
            elif (event["classification"] == "Potential Industrial Fire" or
                  (event["anomaly_status"] == "Anomaly" and event["distance_to_facility_km"] <= 5)):
                risk_categories["High"].append(event)
            elif event["classification"] == "Persistent Industrial Thermal Source":
                risk_categories["Medium"].append(event)
            else:
                risk_categories["Low"].append(event)
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.markdown(f"""
            <div class="alert-card">
                <h3 style="color: white; text-align: center;">{len(risk_categories['Critical'])}</h3>
                <p style="text-align: center; margin: 0;">Critical Risk</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col2:
            st.markdown(f"""
            <div class="warning-card">
                <h3 style="color: white; text-align: center;">{len(risk_categories['High'])}</h3>
                <p style="text-align: center; margin: 0;">High Risk</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col3:
            st.markdown(f"""
            <div style="background: #ffaa00; padding: 1.5rem; border-radius: 10px; color: white;">
                <h3 style="text-align: center;">{len(risk_categories['Medium'])}</h3>
                <p style="text-align: center; margin: 0;">Medium Risk</p>
            </div>
            """, unsafe_allow_html=True)
        
        with col4:
            st.markdown(f"""
            <div style="background: #00C851; padding: 1.5rem; border-radius: 10px; color: white;">
                <h3 style="text-align: center;">{len(risk_categories['Low'])}</h3>
                <p style="text-align: center; margin: 0;">Low Risk</p>
            </div>
            """, unsafe_allow_html=True)
        
        # Risk details
        if len(risk_categories["Critical"]) > 0:
            st.markdown("#### Critical Risk Events")
            critical_df = pd.DataFrame(risk_categories["Critical"])[[
                "event_id", "nearest_facility", "peak_frp", "distance_to_facility_km", "duration_hours"
            ]]
            st.dataframe(critical_df, use_container_width=True)
    
    # Data Export Section
    with st.expander("📥 Detailed Event Data"):
        st.dataframe(
            filtered_events[[
                "event_id", "latitude", "longitude", "classification", "detections",
                "duration_hours", "peak_frp", "nearest_facility", "distance_to_facility_km",
                "anomaly_status", "anomaly_score", "prototype_score"
            ]],
            use_container_width=True,
            height=400
        )
    
    st.markdown("---")
    
    # Export Options
    st.subheader("💾 Export Options")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("### 📄 CSV Export")
        if st.button("Export Events (CSV)", use_container_width=True):
            csv = filtered_events.to_csv(index=False)
            st.download_button(
                "Download Events CSV",
                csv,
                f"thermointel_events_{report_date.strftime('%Y%m%d')}.csv",
                "text/csv",
                use_container_width=True
            )
        
        if st.button("Export Detections (CSV)", use_container_width=True):
            # Filter detections by event IDs
            filtered_detection_ids = filtered_events["event_id"].tolist()
            filtered_detections = detections[detections["event_id"].isin(filtered_detection_ids)]
            csv = filtered_detections.to_csv(index=False)
            st.download_button(
                "Download Detections CSV",
                csv,
                f"thermointel_detections_{report_date.strftime('%Y%m%d')}.csv",
                "text/csv",
                use_container_width=True
            )
    
    with col2:
        st.markdown("### 📊 Excel Export")
        if st.button("Export Full Report (Excel)", use_container_width=True):
            output = io.BytesIO()
            with pd.ExcelWriter(output, engine='openpyxl') as writer:
                # Events sheet
                filtered_events.to_excel(writer, sheet_name='Events', index=False)
                
                # Facility statistics sheet
                if facility_stats:
                    pd.DataFrame(facility_stats).to_excel(writer, sheet_name='Facility Analysis', index=False)
                
                # Risk summary sheet
                risk_summary = pd.DataFrame([
                    {"Risk Level": "Critical", "Count": len(risk_categories["Critical"])},
                    {"Risk Level": "High", "Count": len(risk_categories["High"])},
                    {"Risk Level": "Medium", "Count": len(risk_categories["Medium"])},
                    {"Risk Level": "Low", "Count": len(risk_categories["Low"])}
                ])
                risk_summary.to_excel(writer, sheet_name='Risk Summary', index=False)
            
            st.download_button(
                "Download Excel Report",
                output.getvalue(),
                f"thermointel_report_{report_date.strftime('%Y%m%d')}.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True
            )
    
    with col3:
        st.markdown("### 📋 JSON Export")
        if st.button("Export JSON", use_container_width=True):
            json_data = filtered_events.to_json(orient='records', indent=2)
            st.download_button(
                "Download JSON",
                json_data,
                f"thermointel_events_{report_date.strftime('%Y%m%d')}.json",
                "application/json",
                use_container_width=True
            )
    
    st.markdown("---")
    
    # Report Generation Summary
    st.subheader("✅ Report Summary")
    
    summary_col1, summary_col2 = st.columns(2)
    
    with summary_col1:
        st.markdown("""
        **Report Contains:**
        - Executive summary with key metrics
        - Facility-level analysis and rankings
        - Event classification breakdown
        - Risk assessment matrix
        - Complete event data table
        - Export-ready formats (CSV, Excel, JSON)
        """)
    
    with summary_col2:
        st.markdown(f"""
        **Report Statistics:**
        - Events Included: {len(filtered_events)}
        - Facilities Analyzed: {len(facilities)}
        - Date Range: {report_date.strftime('%B %d, %Y')}
        - Report Type: {report_type}
        - Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        """)
