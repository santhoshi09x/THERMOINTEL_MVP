"""Event Clustering Analysis with Advanced Visualizations."""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np
from scipy.cluster.hierarchy import dendrogram, linkage


def show():
    """Display event analysis page."""
    events = st.session_state.events
    detections = st.session_state.detections
    
    st.markdown('<div class="main-header">📈 EVENT ANALYSIS & CLUSTERING</div>', unsafe_allow_html=True)
    
    # Event filter options
    st.sidebar.markdown("### 🎯 Filter Options")
    
    classification_filter = st.sidebar.multiselect(
        "Classification",
        options=events["classification"].unique().tolist(),
        default=events["classification"].unique().tolist()
    )
    
    anomaly_filter = st.sidebar.multiselect(
        "Anomaly Status",
        options=events["anomaly_status"].unique().tolist(),
        default=events["anomaly_status"].unique().tolist()
    )
    
    min_frp = st.sidebar.slider(
        "Minimum Peak FRP (MW)",
        min_value=float(events["peak_frp"].min()),
        max_value=float(events["peak_frp"].max()),
        value=float(events["peak_frp"].min())
    )
    
    # Apply filters
    filtered_events = events[
        (events["classification"].isin(classification_filter)) &
        (events["anomaly_status"].isin(anomaly_filter)) &
        (events["peak_frp"] >= min_frp)
    ]
    
    st.info(f"📊 Showing {len(filtered_events)} of {len(events)} events")
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        avg_detections = filtered_events["detections"].mean()
        st.metric("Avg Detections/Event", f"{avg_detections:.1f}")
    
    with col2:
        avg_duration = filtered_events["duration_hours"].mean()
        st.metric("Avg Duration", f"{avg_duration:.1f} hrs")
    
    with col3:
        avg_spread = filtered_events["spatial_spread_km"].mean()
        st.metric("Avg Spatial Spread", f"{avg_spread:.2f} km")
    
    with col4:
        avg_persistence = filtered_events["persistence_days"].mean()
        st.metric("Avg Persistence", f"{avg_persistence:.1f} days")
    
    st.markdown("---")
    
    # Tab layout for different analyses
    tab1, tab2, tab3, tab4 = st.tabs([
        "🔍 Cluster Visualization",
        "📊 Statistical Analysis",
        "⏱️ Temporal Patterns",
        "🌐 Spatial Analysis"
    ])
    
    with tab1:
        st.subheader("Event Clustering Visualization")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # 3D scatter plot of event clusters
            st.markdown("**3D Event Distribution**")
            fig_3d = px.scatter_3d(
                filtered_events,
                x="latitude",
                y="longitude",
                z="peak_frp",
                color="classification",
                size="detections",
                hover_data=["event_id", "nearest_facility"],
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={
                    "latitude": "Latitude",
                    "longitude": "Longitude",
                    "peak_frp": "Peak FRP (MW)"
                }
            )
            fig_3d.update_layout(height=500)
            st.plotly_chart(fig_3d, use_container_width=True)
        
        with col2:
            # Feature space clustering (FRP vs Duration)
            st.markdown("**Feature Space: FRP vs Duration**")
            fig_cluster = px.scatter(
                filtered_events,
                x="duration_hours",
                y="peak_frp",
                color="classification",
                size="detections",
                hover_data=["event_id", "spatial_spread_km"],
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={
                    "duration_hours": "Duration (hours)",
                    "peak_frp": "Peak FRP (MW)"
                }
            )
            fig_cluster.update_layout(height=500)
            st.plotly_chart(fig_cluster, use_container_width=True)
        
        # Hierarchical clustering dendrogram
        st.markdown("**🌳 Hierarchical Clustering Dendrogram**")
        
        if len(filtered_events) > 2:
            # Prepare features for clustering
            cluster_features = filtered_events[[
                "peak_frp", "duration_hours", "spatial_spread_km",
                "detections", "distance_to_facility_km"
            ]].fillna(0)
            
            # Normalize features
            from sklearn.preprocessing import StandardScaler
            scaler = StandardScaler()
            normalized_features = scaler.fit_transform(cluster_features)
            
            # Perform hierarchical clustering
            linkage_matrix = linkage(normalized_features[:min(50, len(normalized_features))], method='ward')
            
            # Create dendrogram
            fig_dendro = go.Figure()
            
            def create_dendrogram_trace(Z):
                # Calculate dendrogram
                from scipy.cluster.hierarchy import dendrogram as scipy_dendrogram
                dend = scipy_dendrogram(Z, no_plot=True)
                
                icoord = np.array(dend['icoord'])
                dcoord = np.array(dend['dcoord'])
                
                for i in range(len(icoord)):
                    fig_dendro.add_trace(go.Scatter(
                        x=icoord[i],
                        y=dcoord[i],
                        mode='lines',
                        line=dict(color='blue', width=2),
                        hoverinfo='skip',
                        showlegend=False
                    ))
            
            create_dendrogram_trace(linkage_matrix)
            
            fig_dendro.update_layout(
                title="Event Similarity Dendrogram (Ward Method)",
                xaxis_title="Event Index",
                yaxis_title="Distance",
                height=400,
                showlegend=False
            )
            st.plotly_chart(fig_dendro, use_container_width=True)
    
    with tab2:
        st.subheader("Statistical Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Distribution analysis
            st.markdown("**📊 Feature Distributions**")
            
            feature_select = st.selectbox(
                "Select Feature",
                ["peak_frp", "duration_hours", "spatial_spread_km", "detections", "distance_to_facility_km"]
            )
            
            fig_dist = px.histogram(
                filtered_events,
                x=feature_select,
                color="classification",
                nbins=30,
                marginal="box",
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={feature_select: feature_select.replace("_", " ").title()}
            )
            fig_dist.update_layout(height=400)
            st.plotly_chart(fig_dist, use_container_width=True)
        
        with col2:
            # Box plot comparison
            st.markdown("**📦 Classification Comparison**")
            
            fig_box = px.box(
                filtered_events,
                x="classification",
                y=feature_select,
                color="classification",
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={feature_select: feature_select.replace("_", " ").title()}
            )
            fig_box.update_layout(height=400, showlegend=False)
            st.plotly_chart(fig_box, use_container_width=True)
        
        # Correlation matrix
        st.markdown("**🔗 Feature Correlation Matrix**")
        
        corr_features = filtered_events[[
            "peak_frp", "duration_hours", "spatial_spread_km",
            "detections", "distance_to_facility_km", "persistence_days", "anomaly_score"
        ]]
        
        corr_matrix = corr_features.corr()
        
        fig_corr = px.imshow(
            corr_matrix,
            text_auto=True,
            color_continuous_scale="RdBu_r",
            aspect="auto",
            labels=dict(color="Correlation")
        )
        fig_corr.update_layout(height=500)
        st.plotly_chart(fig_corr, use_container_width=True)
        
        # Statistical summary
        st.markdown("**📈 Statistical Summary**")
        summary_stats = filtered_events[[
            "peak_frp", "duration_hours", "spatial_spread_km",
            "detections", "distance_to_facility_km", "persistence_days"
        ]].describe()
        st.dataframe(summary_stats, use_container_width=True)
    
    with tab3:
        st.subheader("Temporal Patterns")
        
        # Check if timestamp data is available
        if "event_timestamp" in detections.columns:
            detections_with_time = detections.dropna(subset=["event_timestamp"])
            
            if not detections_with_time.empty:
                detections_with_time["timestamp"] = pd.to_datetime(detections_with_time["event_timestamp"])
                detections_with_time["date"] = detections_with_time["timestamp"].dt.date
                detections_with_time["hour"] = detections_with_time["timestamp"].dt.hour
                detections_with_time["day_of_week"] = detections_with_time["timestamp"].dt.day_name()
                
                col1, col2 = st.columns(2)
                
                with col1:
                    # Daily detection trend
                    st.markdown("**📅 Daily Detection Trend**")
                    daily_trend = detections_with_time.groupby("date").size().reset_index(name="count")
                    
                    fig_daily = px.line(
                        daily_trend,
                        x="date",
                        y="count",
                        markers=True,
                        labels={"date": "Date", "count": "Number of Detections"}
                    )
                    fig_daily.update_layout(height=350)
                    st.plotly_chart(fig_daily, use_container_width=True)
                
                with col2:
                    # Hourly pattern
                    st.markdown("**🕐 Hourly Detection Pattern**")
                    hourly_pattern = detections_with_time.groupby("hour").size().reset_index(name="count")
                    
                    fig_hourly = px.bar(
                        hourly_pattern,
                        x="hour",
                        y="count",
                        labels={"hour": "Hour of Day", "count": "Number of Detections"},
                        color="count",
                        color_continuous_scale="YlOrRd"
                    )
                    fig_hourly.update_layout(height=350, showlegend=False)
                    st.plotly_chart(fig_hourly, use_container_width=True)
                
                # Day of week analysis
                st.markdown("**📆 Day of Week Analysis**")
                dow_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
                dow_pattern = detections_with_time.groupby("day_of_week").size().reindex(dow_order).reset_index(name="count")
                
                fig_dow = px.bar(
                    dow_pattern,
                    x="day_of_week",
                    y="count",
                    labels={"day_of_week": "Day of Week", "count": "Number of Detections"},
                    color="count",
                    color_continuous_scale="Blues"
                )
                fig_dow.update_layout(height=350, showlegend=False)
                st.plotly_chart(fig_dow, use_container_width=True)
                
                # Heatmap: Day vs Hour
                st.markdown("**🔥 Detection Heatmap: Day vs Hour**")
                heatmap_data = detections_with_time.groupby(["day_of_week", "hour"]).size().unstack(fill_value=0)
                heatmap_data = heatmap_data.reindex(dow_order)
                
                fig_heatmap = px.imshow(
                    heatmap_data,
                    labels=dict(x="Hour of Day", y="Day of Week", color="Detections"),
                    color_continuous_scale="YlOrRd",
                    aspect="auto"
                )
                fig_heatmap.update_layout(height=400)
                st.plotly_chart(fig_heatmap, use_container_width=True)
            else:
                st.warning("⚠️ No valid timestamp data available for temporal analysis")
        else:
            st.warning("⚠️ Timestamp column not found in detection data")
    
    with tab4:
        st.subheader("Spatial Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Spatial density by classification
            st.markdown("**🗺️ Spatial Density Heatmap**")
            fig_density = px.density_mapbox(
                filtered_events,
                lat="latitude",
                lon="longitude",
                z="peak_frp",
                radius=15,
                mapbox_style="open-street-map",
                zoom=6,
                height=400,
                color_continuous_scale="Hot",
                labels={"peak_frp": "Peak FRP (MW)"}
            )
            st.plotly_chart(fig_density, use_container_width=True)
        
        with col2:
            # Geographic distribution
            st.markdown("**📍 Geographic Event Distribution**")
            fig_geo = px.scatter_mapbox(
                filtered_events,
                lat="latitude",
                lon="longitude",
                color="classification",
                size="detections",
                hover_data=["event_id", "nearest_facility"],
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                mapbox_style="open-street-map",
                zoom=6,
                height=400
            )
            st.plotly_chart(fig_geo, use_container_width=True)
        
        # Spatial clustering analysis
        st.markdown("**🎯 Spatial Clustering Metrics**")
        
        col3, col4, col5 = st.columns(3)
        
        with col3:
            avg_lat = filtered_events["latitude"].mean()
            lat_std = filtered_events["latitude"].std()
            st.metric("Latitude Center", f"{avg_lat:.4f}°")
            st.metric("Latitude Spread", f"±{lat_std:.4f}°")
        
        with col4:
            avg_lon = filtered_events["longitude"].mean()
            lon_std = filtered_events["longitude"].std()
            st.metric("Longitude Center", f"{avg_lon:.4f}°")
            st.metric("Longitude Spread", f"±{lon_std:.4f}°")
        
        with col5:
            avg_spatial = filtered_events["spatial_spread_km"].mean()
            max_spatial = filtered_events["spatial_spread_km"].max()
            st.metric("Avg Event Spread", f"{avg_spatial:.2f} km")
            st.metric("Max Event Spread", f"{max_spatial:.2f} km")
        
        # Spatial spread distribution
        st.markdown("**📏 Spatial Spread Distribution**")
        fig_spread = px.violin(
            filtered_events,
            x="classification",
            y="spatial_spread_km",
            color="classification",
            box=True,
            color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
            labels={"spatial_spread_km": "Spatial Spread (km)"}
        )
        fig_spread.update_layout(height=400, showlegend=False)
        st.plotly_chart(fig_spread, use_container_width=True)
