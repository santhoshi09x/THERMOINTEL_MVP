"""Facility-Level Analysis with Detailed Graphs and Metrics."""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import numpy as np


def show():
    """Display facility analysis page."""
    events = st.session_state.events
    detections = st.session_state.detections
    facilities = st.session_state.facilities
    
    st.markdown('<div class="main-header">🏭 FACILITY ANALYSIS</div>', unsafe_allow_html=True)
    
    # Facility selector
    st.sidebar.markdown("### 🎯 Filter Options")
    
    # Get unique facilities
    facility_list = ["All Facilities"] + sorted(events["nearest_facility"].unique().tolist())
    selected_facility = st.sidebar.selectbox("Select Facility", facility_list)
    
    # Filter events by facility
    if selected_facility != "All Facilities":
        facility_events = events[events["nearest_facility"] == selected_facility]
        st.info(f"📍 Showing analysis for: **{selected_facility}**")
    else:
        facility_events = events
        st.info("📍 Showing analysis for: **All Facilities**")
    
    # Overview metrics
    col1, col2, col3, col4, col5 = st.columns(5)
    
    with col1:
        total_events = len(facility_events)
        st.metric("Total Events", total_events)
    
    with col2:
        avg_frp = facility_events["peak_frp"].mean()
        st.metric("Avg Peak FRP", f"{avg_frp:.1f} MW")
    
    with col3:
        total_detections = facility_events["detections"].sum()
        st.metric("Total Detections", total_detections)
    
    with col4:
        avg_distance = facility_events["distance_to_facility_km"].mean()
        st.metric("Avg Distance", f"{avg_distance:.2f} km")
    
    with col5:
        high_risk = len(facility_events[facility_events["classification"] == "Potential Industrial Fire"])
        st.metric("High Risk Events", high_risk)
    
    st.markdown("---")
    
    # Facility ranking table
    st.subheader("🏆 Facility Risk Ranking")
    
    # Calculate facility-level statistics
    facility_stats = []
    for facility in facilities.itertuples():
        fac_events = events[events["nearest_facility"] == facility.facility]
        
        if len(fac_events) > 0:
            facility_stats.append({
                "Facility": facility.facility,
                "Type": facility.facility_type,
                "Total Events": len(fac_events),
                "Industrial Fires": len(fac_events[fac_events["classification"] == "Potential Industrial Fire"]),
                "Persistent Sources": len(fac_events[fac_events["classification"] == "Persistent Industrial Thermal Source"]),
                "Avg Peak FRP (MW)": fac_events["peak_frp"].mean(),
                "Max Peak FRP (MW)": fac_events["peak_frp"].max(),
                "Total Detections": fac_events["detections"].sum(),
                "Avg Distance (km)": fac_events["distance_to_facility_km"].mean(),
                "Anomalies": len(fac_events[fac_events["anomaly_status"] == "Anomaly"]),
            })
    
    facility_df = pd.DataFrame(facility_stats)
    if not facility_df.empty:
        # Calculate risk score
        facility_df["Risk Score"] = (
            facility_df["Industrial Fires"] * 10 +
            facility_df["Persistent Sources"] * 5 +
            facility_df["Anomalies"] * 3 +
            (facility_df["Avg Peak FRP (MW)"] / 10)
        ).round(1)
        
        facility_df = facility_df.sort_values("Risk Score", ascending=False)
        
        # Color code risk scores
        def highlight_risk(row):
            if row["Risk Score"] > 50:
                return ['background-color: #ffcccc'] * len(row)
            elif row["Risk Score"] > 20:
                return ['background-color: #ffffcc'] * len(row)
            else:
                return ['background-color: #ccffcc'] * len(row)
        
        st.dataframe(
            facility_df.style.apply(highlight_risk, axis=1),
            use_container_width=True,
            height=400
        )
    
    st.markdown("---")
    
    # Detailed facility charts
    if selected_facility != "All Facilities":
        st.subheader(f"📊 Detailed Analysis: {selected_facility}")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Event classification breakdown
            st.markdown("**Event Classification**")
            class_counts = facility_events["classification"].value_counts()
            fig_class = px.bar(
                x=class_counts.index,
                y=class_counts.values,
                color=class_counts.index,
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={"x": "Classification", "y": "Count"}
            )
            fig_class.update_layout(showlegend=False, height=300)
            st.plotly_chart(fig_class, use_container_width=True)
        
        with col2:
            # Anomaly status
            st.markdown("**Anomaly Detection**")
            anomaly_counts = facility_events["anomaly_status"].value_counts()
            fig_anomaly = px.pie(
                values=anomaly_counts.values,
                names=anomaly_counts.index,
                color_discrete_sequence=["#00C851", "#ff4444"],
                hole=0.4
            )
            fig_anomaly.update_layout(height=300)
            st.plotly_chart(fig_anomaly, use_container_width=True)
        
        col3, col4 = st.columns(2)
        
        with col3:
            # FRP distribution
            st.markdown("**Fire Radiative Power Distribution**")
            fig_frp_dist = px.histogram(
                facility_events,
                x="peak_frp",
                nbins=20,
                color="classification",
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={"peak_frp": "Peak FRP (MW)"}
            )
            fig_frp_dist.update_layout(height=300, showlegend=True)
            st.plotly_chart(fig_frp_dist, use_container_width=True)
        
        with col4:
            # Duration analysis
            st.markdown("**Event Duration Distribution**")
            fig_duration = px.histogram(
                facility_events,
                x="duration_hours",
                nbins=20,
                color="classification",
                color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
                labels={"duration_hours": "Duration (hours)"}
            )
            fig_duration.update_layout(height=300, showlegend=True)
            st.plotly_chart(fig_duration, use_container_width=True)
        
        # Timeline analysis
        st.markdown("**📅 Temporal Analysis**")
        
        # Get detection times for this facility
        facility_event_ids = facility_events["event_id"].tolist()
        facility_detections = detections[detections["event_id"].isin(facility_event_ids)]
        
        if not facility_detections.empty and "event_timestamp" in facility_detections.columns:
            facility_detections["date"] = pd.to_datetime(facility_detections["event_timestamp"]).dt.date
            daily_counts = facility_detections.groupby("date").size().reset_index(name="detections")
            
            fig_timeline = px.line(
                daily_counts,
                x="date",
                y="detections",
                markers=True,
                labels={"date": "Date", "detections": "Number of Detections"}
            )
            fig_timeline.update_layout(height=300)
            st.plotly_chart(fig_timeline, use_container_width=True)
        
        # Spatial heatmap
        st.markdown("**🗺️ Spatial Distribution**")
        fig_spatial = px.density_mapbox(
            facility_events,
            lat="latitude",
            lon="longitude",
            z="peak_frp",
            radius=20,
            mapbox_style="open-street-map",
            zoom=10,
            height=400,
            color_continuous_scale="Hot"
        )
        st.plotly_chart(fig_spatial, use_container_width=True)
        
        # Event details table
        st.markdown("**📋 Event Details**")
        event_details = facility_events[[
            "event_id", "latitude", "longitude", "classification", "detections",
            "duration_hours", "peak_frp", "distance_to_facility_km", "anomaly_status"
        ]].sort_values("peak_frp", ascending=False)
        st.dataframe(event_details, use_container_width=True, height=300)
    
    else:
        # Overview charts for all facilities
        st.subheader("📊 Facility Comparison Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Top facilities by event count
            st.markdown("**Top 10 Facilities by Event Count**")
            top_facilities = events["nearest_facility"].value_counts().head(10)
            fig_top = px.bar(
                x=top_facilities.values,
                y=top_facilities.index,
                orientation='h',
                color=top_facilities.values,
                color_continuous_scale="Reds",
                labels={"x": "Number of Events", "y": "Facility"}
            )
            fig_top.update_layout(height=400, showlegend=False)
            st.plotly_chart(fig_top, use_container_width=True)
        
        with col2:
            # Facility type distribution
            st.markdown("**Event Distribution by Facility Type**")
            type_counts = events["facility_type"].value_counts()
            fig_type = px.pie(
                values=type_counts.values,
                names=type_counts.index,
                hole=0.4
            )
            fig_type.update_layout(height=400)
            st.plotly_chart(fig_type, use_container_width=True)
        
        # Facility comparison heatmap
        st.markdown("**🔥 Facility Risk Heatmap**")
        
        if not facility_df.empty:
            # Select top 15 facilities for heatmap
            top_15 = facility_df.head(15)
            
            # Create heatmap data
            heatmap_data = top_15[[
                "Industrial Fires", "Persistent Sources", "Anomalies",
                "Avg Peak FRP (MW)", "Total Detections"
            ]].T
            
            fig_heatmap = px.imshow(
                heatmap_data,
                x=top_15["Facility"],
                y=heatmap_data.index,
                color_continuous_scale="YlOrRd",
                aspect="auto",
                labels=dict(x="Facility", y="Metric", color="Value")
            )
            fig_heatmap.update_layout(height=400)
            st.plotly_chart(fig_heatmap, use_container_width=True)
        
        # Scatter plot: Distance vs FRP
        st.markdown("**📍 Distance vs Fire Intensity Analysis**")
        fig_scatter = px.scatter(
            events,
            x="distance_to_facility_km",
            y="peak_frp",
            color="facility_type",
            size="detections",
            hover_data=["event_id", "nearest_facility", "classification"],
            labels={
                "distance_to_facility_km": "Distance to Facility (km)",
                "peak_frp": "Peak FRP (MW)",
                "facility_type": "Facility Type"
            }
        )
        fig_scatter.update_layout(height=500)
        st.plotly_chart(fig_scatter, use_container_width=True)
