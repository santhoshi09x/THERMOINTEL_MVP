"""Page modules for THERMOINTEL dashboard."""
