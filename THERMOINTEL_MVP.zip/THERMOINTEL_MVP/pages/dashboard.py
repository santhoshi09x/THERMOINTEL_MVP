"""Main Dashboard - Overview with Map and Key Metrics."""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import folium
from streamlit_folium import st_folium
from datetime import datetime


def show():
    """Display main dashboard."""
    events = st.session_state.events
    detections = st.session_state.detections
    facilities = st.session_state.facilities
    
    st.markdown('<div class="main-header">🎯 GIS DASHBOARD & ALERTS</div>', unsafe_allow_html=True)
    
    # Key Metrics Row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        total_detections = len(detections)
        st.markdown(f"""
        <div style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); 
                    padding: 1.5rem; border-radius: 10px; color: white; text-align: center;">
            <div style="font-size: 0.9rem; opacity: 0.9;">Thermal Detections</div>
            <div style="font-size: 2.5rem; font-weight: bold; margin: 0.5rem 0;">{total_detections}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        total_events = len(events)
        st.markdown(f"""
        <div style="background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); 
                    padding: 1.5rem; border-radius: 10px; color: white; text-align: center;">
            <div style="font-size: 0.9rem; opacity: 0.9;">Thermal Events</div>
            <div style="font-size: 2.5rem; font-weight: bold; margin: 0.5rem 0;">{total_events}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        industrial_fires = int(events["classification"].eq("Potential Industrial Fire").sum())
        st.markdown(f"""
        <div style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%); 
                    padding: 1.5rem; border-radius: 10px; color: white; text-align: center;">
            <div style="font-size: 0.9rem; opacity: 0.9;">Potential Industrial Fires</div>
            <div style="font-size: 2.5rem; font-weight: bold; margin: 0.5rem 0;">{industrial_fires}</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col4:
        persistent_sources = int(events["classification"].eq("Persistent Industrial Thermal Source").sum())
        st.markdown(f"""
        <div style="background: linear-gradient(135deg, #30cfd0 0%, #330867 100%); 
                    padding: 1.5rem; border-radius: 10px; color: white; text-align: center;">
            <div style="font-size: 0.9rem; opacity: 0.9;">Persistent Sources</div>
            <div style="font-size: 2.5rem; font-weight: bold; margin: 0.5rem 0;">{persistent_sources}</div>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Map and Statistics Side by Side
    col_map, col_stats = st.columns([2, 1])
    
    with col_map:
        st.subheader("🗺️ Interactive Event Map")
        
        # Create map
        event_center = [events["latitude"].mean(), events["longitude"].mean()]
        event_map = folium.Map(location=event_center, zoom_start=7, tiles="OpenStreetMap")
        
        # Color mapping
        colors = {
            "Potential Industrial Fire": "red",
            "Persistent Industrial Thermal Source": "orange",
            "Natural / Other Thermal Event": "blue",
        }
        
        # Add events
        for event in events.itertuples():
            history = "<br>".join(event.event_history) if event.event_history else "No valid acquisition time"
            popup = (
                f"<b>Event: {event.event_id}</b><br>"
                f"<b>Classification:</b> {event.classification}<br>"
                f"<b>Confidence:</b> {event.prototype_score:.0f}%<br>"
                f"<b>Detections:</b> {event.detections}<br>"
                f"<b>Duration:</b> {event.duration_hours:.1f} hours<br>"
                f"<b>Persistence:</b> {event.persistence_days} day(s)<br>"
                f"<b>Peak FRP:</b> {event.peak_frp:.1f} MW<br>"
                f"<b>Anomaly:</b> {event.anomaly_status} (score: {event.anomaly_score:.3f})<br>"
                f"<b>Nearest Facility:</b> {event.nearest_facility}<br>"
                f"<b>Facility Type:</b> {event.facility_type}<br>"
                f"<b>Distance:</b> {event.distance_to_facility_km:.2f} km<br>"
                f"<hr><b>Detection History:</b><br>{history}"
            )
            
            folium.CircleMarker(
                [event.latitude, event.longitude],
                radius=8 + (event.detections / 2),
                color=colors[event.classification],
                fill=True,
                fill_opacity=0.7,
                popup=folium.Popup(popup, max_width=350),
                tooltip=f"{event.event_id}: {event.classification}"
            ).add_to(event_map)
        
        # Add facilities
        for facility in facilities.itertuples():
            folium.Marker(
                [facility.latitude, facility.longitude],
                tooltip=f"{facility.facility} ({facility.facility_type})",
                icon=folium.Icon(color="gray", icon="industry", prefix="fa"),
            ).add_to(event_map)
        
        # Add legend
        legend_html = """
        <div style="position: fixed; bottom: 50px; left: 50px; width: 220px; height: 140px; 
                    background-color: white; border:2px solid grey; z-index:9999; font-size:14px;
                    padding: 10px; border-radius: 5px;">
            <p style="margin-bottom: 5px;"><b>Event Classification</b></p>
            <p style="margin: 3px;"><i class="fa fa-circle" style="color:red"></i> Potential Industrial Fire</p>
            <p style="margin: 3px;"><i class="fa fa-circle" style="color:orange"></i> Persistent Thermal Source</p>
            <p style="margin: 3px;"><i class="fa fa-circle" style="color:blue"></i> Natural / Other</p>
            <p style="margin: 3px;"><i class="fa fa-industry" style="color:gray"></i> Industrial Facility</p>
        </div>
        """
        event_map.get_root().html.add_child(folium.Element(legend_html))
        
        st_folium(event_map, width=None, height=500)
    
    with col_stats:
        st.subheader("📊 Quick Statistics")
        
        # Anomaly distribution
        anomaly_counts = events["anomaly_status"].value_counts()
        if not anomaly_counts.empty:
            st.markdown("**Anomaly Detection**")
            for status, count in anomaly_counts.items():
                percentage = (count / len(events)) * 100
                st.markdown(f"- {status}: {count} ({percentage:.1f}%)")
        
        st.markdown("---")
        
        # Classification breakdown
        st.markdown("**Classification Breakdown**")
        class_counts = events["classification"].value_counts()
        for classification, count in class_counts.items():
            percentage = (count / len(events)) * 100
            st.markdown(f"- {classification}: {count} ({percentage:.1f}%)")
        
        st.markdown("---")
        
        # Facility proximity
        st.markdown("**Facility Proximity**")
        within_1km = len(events[events["distance_to_facility_km"] <= 1])
        within_5km = len(events[events["distance_to_facility_km"] <= 5])
        beyond_5km = len(events[events["distance_to_facility_km"] > 5])
        
        st.markdown(f"- Within 1 km: {within_1km}")
        st.markdown(f"- Within 5 km: {within_5km}")
        st.markdown(f"- Beyond 5 km: {beyond_5km}")
        
        st.markdown("---")
        
        # Top facilities by event count
        st.markdown("**Top 5 Facilities by Events**")
        top_facilities = events["nearest_facility"].value_counts().head(5)
        for facility, count in top_facilities.items():
            st.markdown(f"- {facility}: {count}")
    
    st.markdown("---")
    
    # Charts Row
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("📈 Event Classification Distribution")
        class_counts = events["classification"].value_counts()
        fig_pie = px.pie(
            values=class_counts.values,
            names=class_counts.index,
            color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
            hole=0.4
        )
        fig_pie.update_layout(height=350)
        st.plotly_chart(fig_pie, use_container_width=True)
    
    with col2:
        st.subheader("🔥 Fire Radiative Power Distribution")
        fig_frp = px.histogram(
            events,
            x="peak_frp",
            nbins=30,
            color="classification",
            color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
            labels={"peak_frp": "Peak FRP (MW)", "count": "Number of Events"}
        )
        fig_frp.update_layout(height=350, showlegend=True)
        st.plotly_chart(fig_frp, use_container_width=True)
    
    # Additional charts
    col3, col4 = st.columns(2)
    
    with col3:
        st.subheader("⏱️ Event Duration Analysis")
        fig_duration = px.box(
            events,
            x="classification",
            y="duration_hours",
            color="classification",
            color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
            labels={"duration_hours": "Duration (hours)", "classification": "Classification"}
        )
        fig_duration.update_layout(height=350, showlegend=False)
        st.plotly_chart(fig_duration, use_container_width=True)
    
    with col4:
        st.subheader("📍 Distance to Nearest Facility")
        fig_distance = px.scatter(
            events,
            x="distance_to_facility_km",
            y="peak_frp",
            color="classification",
            size="detections",
            hover_data=["event_id", "nearest_facility"],
            color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
            labels={
                "distance_to_facility_km": "Distance to Facility (km)",
                "peak_frp": "Peak FRP (MW)",
                "detections": "Detections"
            }
        )
        fig_distance.update_layout(height=350)
        st.plotly_chart(fig_distance, use_container_width=True)
    
    # Critical Alerts Section
    st.markdown("---")
    st.subheader("🚨 Critical Alerts & Notifications")
    
    # High-risk events
    high_risk = events[
        (events["classification"] == "Potential Industrial Fire") &
        (events["distance_to_facility_km"] <= 2) &
        (events["peak_frp"] > events["peak_frp"].quantile(0.75))
    ]
    
    if len(high_risk) > 0:
        for event in high_risk.itertuples():
            st.markdown(f"""
            <div class="alert-card">
                <b>⚠️ HIGH RISK ALERT - {event.event_id}</b><br>
                Potential industrial fire detected {event.distance_to_facility_km:.2f} km from {event.nearest_facility}<br>
                Peak FRP: {event.peak_frp:.1f} MW | Duration: {event.duration_hours:.1f} hours | Detections: {event.detections}
            </div>
            """, unsafe_allow_html=True)
    
    # Anomalies near facilities
    anomaly_alerts = events[
        (events["anomaly_status"] == "Anomaly") &
        (events["distance_to_facility_km"] <= 5)
    ]
    
    if len(anomaly_alerts) > 0:
        for event in anomaly_alerts.head(3).itertuples():
            st.markdown(f"""
            <div class="warning-card">
                <b>⚡ ANOMALY DETECTED - {event.event_id}</b><br>
                Unusual thermal activity near {event.nearest_facility} ({event.facility_type})<br>
                Anomaly Score: {event.anomaly_score:.3f} | Distance: {event.distance_to_facility_km:.2f} km
            </div>
            """, unsafe_allow_html=True)
