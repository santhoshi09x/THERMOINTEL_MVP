"""AI-Driven Insights and Alerts."""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime


def show():
    """Display insights and alerts page."""
    events = st.session_state.events
    detections = st.session_state.detections
    facilities = st.session_state.facilities
    
    st.markdown('<div class="main-header">💡 INSIGHTS & ALERTS</div>', unsafe_allow_html=True)
    
    # Priority Alerts Section
    st.subheader("🚨 Priority Alerts")
    
    # Critical high-risk events
    critical_events = events[
        (events["classification"] == "Potential Industrial Fire") &
        (events["distance_to_facility_km"] <= 2) &
        (events["peak_frp"] > events["peak_frp"].quantile(0.75))
    ].sort_values("peak_frp", ascending=False)
    
    if len(critical_events) > 0:
        st.markdown("### 🔴 CRITICAL ALERTS")
        for idx, event in enumerate(critical_events.head(5).itertuples(), 1):
            st.markdown(f"""
            <div class="alert-card">
                <h4>⚠️ Alert #{idx}: {event.event_id}</h4>
                <b>Classification:</b> {event.classification}<br>
                <b>Location:</b> {event.latitude:.4f}°, {event.longitude:.4f}°<br>
                <b>Nearest Facility:</b> {event.nearest_facility} ({event.facility_type})<br>
                <b>Distance:</b> {event.distance_to_facility_km:.2f} km<br>
                <b>Peak FRP:</b> {event.peak_frp:.1f} MW<br>
                <b>Duration:</b> {event.duration_hours:.1f} hours ({event.persistence_days} days)<br>
                <b>Detections:</b> {event.detections}<br>
                <b>Confidence Score:</b> {event.prototype_score:.0f}%<br>
                <br>
                <b>Recommendation:</b> Immediate investigation required. High thermal intensity near industrial facility.
            </div>
            """, unsafe_allow_html=True)
    else:
        st.success("✅ No critical alerts at this time")
    
    st.markdown("---")
    
    # Warning-level alerts (anomalies near facilities)
    warning_events = events[
        (events["anomaly_status"] == "Anomaly") &
        (events["distance_to_facility_km"] <= 5) &
        (~events.index.isin(critical_events.index))
    ].sort_values("anomaly_score", ascending=False)
    
    if len(warning_events) > 0:
        st.markdown("### 🟡 WARNING ALERTS")
        for idx, event in enumerate(warning_events.head(5).itertuples(), 1):
            st.markdown(f"""
            <div class="warning-card">
                <h4>⚡ Warning #{idx}: {event.event_id}</h4>
                <b>Classification:</b> {event.classification}<br>
                <b>Anomaly Score:</b> {event.anomaly_score:.3f}<br>
                <b>Nearest Facility:</b> {event.nearest_facility} ({event.facility_type})<br>
                <b>Distance:</b> {event.distance_to_facility_km:.2f} km<br>
                <b>Peak FRP:</b> {event.peak_frp:.1f} MW<br>
                <br>
                <b>Recommendation:</b> Monitor closely. Unusual thermal activity detected near facility.
            </div>
            """, unsafe_allow_html=True)
    else:
        st.info("ℹ️ No warning-level anomalies detected")
    
    st.markdown("---")
    
    # Positive insights (persistent sources)
    persistent_events = events[
        (events["classification"] == "Persistent Industrial Thermal Source") &
        (events["persistence_days"] >= 2)
    ].sort_values("persistence_days", ascending=False)
    
    if len(persistent_events) > 0:
        st.markdown("### 🟢 ROUTINE MONITORING")
        for idx, event in enumerate(persistent_events.head(3).itertuples(), 1):
            st.markdown(f"""
            <div class="info-card">
                <h4>✓ Routine #{idx}: {event.event_id}</h4>
                <b>Classification:</b> {event.classification}<br>
                <b>Nearest Facility:</b> {event.nearest_facility} ({event.facility_type})<br>
                <b>Distance:</b> {event.distance_to_facility_km:.2f} km<br>
                <b>Persistence:</b> {event.persistence_days} days<br>
                <b>Peak FRP:</b> {event.peak_frp:.1f} MW<br>
                <br>
                <b>Assessment:</b> Consistent with normal industrial operations. Continue routine monitoring.
            </div>
            """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # AI-Driven Insights
    st.subheader("🤖 AI-Driven Insights")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### 📊 Pattern Analysis")
        
        # Most active facilities
        st.markdown("**Most Active Facilities**")
        top_facilities = events.groupby("nearest_facility").agg({
            "event_id": "count",
            "peak_frp": "mean",
            "distance_to_facility_km": "mean"
        }).sort_values("event_id", ascending=False).head(5)
        
        top_facilities.columns = ["Events", "Avg FRP (MW)", "Avg Distance (km)"]
        st.dataframe(top_facilities, use_container_width=True)
        
        # Risk trends
        st.markdown("**Risk Level Distribution**")
        risk_levels = []
        for _, event in events.iterrows():
            if (event["classification"] == "Potential Industrial Fire" and 
                event["distance_to_facility_km"] <= 2 and 
                event["peak_frp"] > events["peak_frp"].quantile(0.75)):
                risk_levels.append("Critical")
            elif event["anomaly_status"] == "Anomaly" and event["distance_to_facility_km"] <= 5:
                risk_levels.append("Warning")
            elif event["classification"] == "Persistent Industrial Thermal Source":
                risk_levels.append("Normal")
            else:
                risk_levels.append("Low")
        
        events["risk_level"] = risk_levels
        risk_counts = events["risk_level"].value_counts()
        
        fig_risk = px.pie(
            values=risk_counts.values,
            names=risk_counts.index,
            color=risk_counts.index,
            color_discrete_map={
                "Critical": "#ff4444",
                "Warning": "#ffaa00",
                "Normal": "#00C851",
                "Low": "#4444ff"
            },
            hole=0.4
        )
        fig_risk.update_layout(height=300)
        st.plotly_chart(fig_risk, use_container_width=True)
    
    with col2:
        st.markdown("### 🎯 Recommendations")
        
        recommendations = []
        
        # Generate dynamic recommendations
        if len(critical_events) > 0:
            recommendations.append({
                "Priority": "🔴 High",
                "Action": f"Investigate {len(critical_events)} critical alert(s)",
                "Details": "High-intensity fires near industrial facilities require immediate attention"
            })
        
        if len(warning_events) > 0:
            recommendations.append({
                "Priority": "🟡 Medium",
                "Action": f"Review {len(warning_events)} anomaly alert(s)",
                "Details": "Unusual thermal patterns detected near facilities"
            })
        
        # Facility-specific recommendations
        high_event_facilities = events.groupby("nearest_facility").size().sort_values(ascending=False).head(3)
        for facility, count in high_event_facilities.items():
            if count > 5:
                recommendations.append({
                    "Priority": "🔵 Info",
                    "Action": f"Monitor {facility}",
                    "Details": f"{count} events detected. Review facility operational patterns"
                })
        
        # Anomaly concentration
        if len(events[events["anomaly_status"] == "Anomaly"]) > len(events) * 0.2:
            recommendations.append({
                "Priority": "🟡 Medium",
                "Action": "High anomaly rate detected",
                "Details": "Consider baseline recalibration or investigation of unusual patterns"
            })
        
        if recommendations:
            for rec in recommendations:
                st.markdown(f"""
                <div style="border-left: 4px solid #1f77b4; padding: 10px; margin: 10px 0; background: #f8f9fa;">
                    <b>{rec['Priority']}</b>: {rec['Action']}<br>
                    <small>{rec['Details']}</small>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.success("✅ No immediate actions required. All systems nominal.")
    
    st.markdown("---")
    
    # Trend Analysis
    st.subheader("📈 Trend Analysis")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # FRP trend by classification
        st.markdown("**Fire Radiative Power Trends**")
        frp_by_class = events.groupby("classification")["peak_frp"].agg(["mean", "max", "std"]).round(2)
        frp_by_class.columns = ["Mean FRP", "Max FRP", "Std Dev"]
        st.dataframe(frp_by_class, use_container_width=True)
        
        fig_frp_trend = px.box(
            events,
            x="classification",
            y="peak_frp",
            color="classification",
            color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
            labels={"peak_frp": "Peak FRP (MW)", "classification": "Classification"}
        )
        fig_frp_trend.update_layout(height=300, showlegend=False)
        st.plotly_chart(fig_frp_trend, use_container_width=True)
    
    with col2:
        # Distance analysis
        st.markdown("**Facility Proximity Analysis**")
        proximity_stats = events.groupby("classification")["distance_to_facility_km"].agg(["mean", "min", "max"]).round(2)
        proximity_stats.columns = ["Mean Distance", "Min Distance", "Max Distance"]
        st.dataframe(proximity_stats, use_container_width=True)
        
        fig_distance = px.violin(
            events,
            x="classification",
            y="distance_to_facility_km",
            color="classification",
            box=True,
            color_discrete_sequence=["#ff4444", "#ffaa00", "#4444ff"],
            labels={"distance_to_facility_km": "Distance (km)", "classification": "Classification"}
        )
        fig_distance.update_layout(height=300, showlegend=False)
        st.plotly_chart(fig_distance, use_container_width=True)
    
    st.markdown("---")
    
    # Predictive Insights
    st.subheader("🔮 Predictive Insights")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("### High-Risk Facilities")
        
        # Calculate facility risk scores
        facility_risk = []
        for facility in facilities.itertuples():
            fac_events = events[events["nearest_facility"] == facility.facility]
            if len(fac_events) > 0:
                risk_score = (
                    len(fac_events[fac_events["classification"] == "Potential Industrial Fire"]) * 10 +
                    len(fac_events[fac_events["anomaly_status"] == "Anomaly"]) * 5 +
                    (fac_events["peak_frp"].mean() / 10)
                )
                facility_risk.append({
                    "Facility": facility.facility,
                    "Risk Score": round(risk_score, 1)
                })
        
        if facility_risk:
            risk_df = pd.DataFrame(facility_risk).sort_values("Risk Score", ascending=False).head(5)
            st.dataframe(risk_df, use_container_width=True, hide_index=True)
    
    with col2:
        st.markdown("### Event Characteristics")
        
        # High-intensity events
        high_intensity = events[events["peak_frp"] > events["peak_frp"].quantile(0.9)]
        st.metric("High Intensity Events", len(high_intensity))
        st.metric("Avg FRP", f"{high_intensity['peak_frp'].mean():.1f} MW")
        
        # Long-duration events
        long_duration = events[events["duration_hours"] > events["duration_hours"].quantile(0.9)]
        st.metric("Long Duration Events", len(long_duration))
        st.metric("Avg Duration", f"{long_duration['duration_hours'].mean():.1f} hrs")
    
    with col3:
        st.markdown("### Anomaly Statistics")
        
        anomalies = events[events["anomaly_status"] == "Anomaly"]
        st.metric("Total Anomalies", len(anomalies))
        
        if len(anomalies) > 0:
            st.metric("Avg Anomaly Score", f"{anomalies['anomaly_score'].mean():.3f}")
            st.metric("Near Facilities", len(anomalies[anomalies["distance_to_facility_km"] <= 5]))
            
            anomaly_rate = (len(anomalies) / len(events)) * 100
            if anomaly_rate > 20:
                st.warning(f"⚠️ High anomaly rate: {anomaly_rate:.1f}%")
            else:
                st.success(f"✅ Normal anomaly rate: {anomaly_rate:.1f}%")
    
    st.markdown("---")
    
    # Export alerts
    st.subheader("📥 Export Alerts")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if st.button("📄 Export Critical Alerts (CSV)", use_container_width=True):
            if len(critical_events) > 0:
                csv = critical_events.to_csv(index=False)
                st.download_button(
                    "Download CSV",
                    csv,
                    "critical_alerts.csv",
                    "text/csv",
                    use_container_width=True
                )
            else:
                st.info("No critical alerts to export")
    
    with col2:
        if st.button("📄 Export Warning Alerts (CSV)", use_container_width=True):
            if len(warning_events) > 0:
                csv = warning_events.to_csv(index=False)
                st.download_button(
                    "Download CSV",
                    csv,
                    "warning_alerts.csv",
                    "text/csv",
                    use_container_width=True
                )
            else:
                st.info("No warning alerts to export")
    
    with col3:
        if st.button("📄 Export All Insights (CSV)", use_container_width=True):
            csv = events.to_csv(index=False)
            st.download_button(
                "Download CSV",
                csv,
                "all_events.csv",
                "text/csv",
                use_container_width=True
            )
