# THERMOINTEL MVP - Enhanced Dashboard

![ThermoIntel](https://img.shields.io/badge/ThermoIntel-MVP-blue)
![Python](https://img.shields.io/badge/Python-3.8+-green)
![Streamlit](https://img.shields.io/badge/Streamlit-Latest-red)

## 🔥 Advanced Industrial Thermal Intelligence Platform

## Run
```powershell
python -m pip install -r requirements.txt
python -m streamlit run streamlit_app.py
```

A demo FIRMS-like CSV is included. You can replace it with a NASA FIRMS CSV using the uploader.

## What this MVP demonstrates
- FIRMS CSV upload and field normalisation
- HDBSCAN event formation (not classification)
- Event-level thermal, temporal, and spatial-spread features
- Isolation Forest anomaly score/status
- Offline facility CSV context enrichment (bundled data is clearly DEMO DATA)
- GIS visualization with event history and facility proximity
- Transparent prototype classification and a future XGBoost training interface

## Important
The prototype classifier is deliberately a transparent rule layer because FIRMS does not provide ready-made labels for all target classes. A validated XGBoost model requires a curated labelled event dataset. CNN visual features should be added after obtaining suitable satellite image patches; no CNN predictions are generated in this MVP.

## Optional facility context
To replace the bundled offline facility context, upload a CSV with these columns:
`facility`, `latitude`, `longitude`, `facility_type`.

GeoJSON Point features are also supported; their properties may use `name` and `type` instead.


## 🎯 Enhanced Features

### 📊 **Multi-Page Dashboard**
- **Dashboard Overview**: Interactive GIS map with real-time alerts and key metrics
- **Facility Analysis**: Detailed facility-level insights with risk rankings and temporal trends
- **Event Analysis**: Advanced clustering visualizations with 3D plots and hierarchical dendrograms
- **Insights & Alerts**: AI-driven recommendations and priority alert system
- **Reports**: Professional report generation with multiple export formats

### 🗺️ **Interactive Visualizations**
- **GIS Mapping**: Interactive Folium maps with event clustering and facility markers
- **3D Scatter Plots**: Spatial-temporal event distribution analysis
- **Heat Maps**: Risk analysis and temporal pattern detection
- **Dendrograms**: Hierarchical clustering visualization
- **Statistical Charts**: Box plots, violin plots, histograms, and correlation matrices

### 🏭 **Facility-Level Analysis**
- Risk scoring and ranking system
- Event count and classification breakdown per facility
- Temporal analysis with daily/hourly detection patterns
- Spatial distribution heat maps
- Facility comparison metrics

### 📈 **Event Clustering & Analysis**
- HDBSCAN-based event formation
- Feature space clustering (FRP vs Duration)
- Spatial spread analysis
- Temporal pattern detection (hourly, daily, weekly)
- Anomaly detection and scoring

### 💡 **AI-Driven Insights**
- **Critical Alerts**: High-risk events near industrial facilities
- **Warning Alerts**: Anomalous thermal patterns requiring attention
- **Routine Monitoring**: Persistent sources with normal operations
- **Predictive Analytics**: Facility risk trends and pattern analysis
- **Dynamic Recommendations**: Context-aware action items

### 📄 **Professional Reporting**
- **Executive Summaries**: High-level overview with key findings
- **Detailed Analysis**: Comprehensive event and facility breakdowns
- **Risk Assessments**: Categorized risk matrices (Critical/High/Medium/Low)
- **Export Formats**: CSV, Excel (XLSX), and JSON
- **Customizable Filters**: Classification, facility, and anomaly-based filtering

## 🚀 Quick Start

### Installation

```bash
# Install dependencies
pip install -r requirements.txt
```

### Running the Enhanced Dashboard

```bash
# Start the new multi-page dashboard
streamlit run app.py

# Or use the legacy single-page version
streamlit run streamlit_app.py
```

### Using the Application

1. **Upload Data**: 
   - Upload NASA FIRMS CSV data via the sidebar
   - Optionally upload facility context (CSV, GeoJSON, JSON)

2. **Process Data**:
   - Click "Process Data" button in the sidebar
   - Wait for pipeline completion

3. **Navigate Sections**:
   - **Dashboard**: Overview and interactive map
   - **Facility Analysis**: Dive into facility-specific metrics
   - **Event Analysis**: Explore clustering and patterns
   - **Insights & Alerts**: Review AI recommendations
   - **Reports**: Generate and export professional reports

## 📊 Dashboard Sections

### 1. Dashboard (Main View)
- **Key Metrics**: Total detections, events, fires, and persistent sources
- **Interactive Map**: GIS visualization with event clustering
- **Quick Statistics**: Anomaly distribution, classification breakdown, facility proximity
- **Charts**: Classification distribution, FRP analysis, duration analysis
- **Critical Alerts**: Real-time high-risk notifications

### 2. Facility Analysis
- **Facility Selector**: Filter by specific facility or view all
- **Risk Ranking Table**: Color-coded facility risk scores
- **Classification Breakdown**: Event types per facility
- **Temporal Analysis**: Daily detection trends
- **Spatial Heatmaps**: Geographic event distribution
- **Comparison Charts**: Top facilities and event distribution

### 3. Event Analysis
- **Clustering Visualization**: 3D scatter plots and feature space analysis
- **Hierarchical Clustering**: Dendrogram visualization (Ward method)
- **Statistical Analysis**: Feature distributions and correlations
- **Temporal Patterns**: Hourly, daily, and weekly detection trends
- **Spatial Analysis**: Geographic density and spread metrics

### 4. Insights & Alerts
- **Priority Alerts**: Critical/Warning/Normal categorization
- **AI Recommendations**: Context-aware action items
- **Pattern Analysis**: Facility activity and risk trends
- **Trend Analysis**: FRP and proximity statistics
- **Predictive Insights**: High-risk facilities and event characteristics

### 5. Reports
- **Report Configuration**: Title, author, date, and type selection
- **Data Filters**: Classification, facility, and anomaly filters
- **Executive Summary**: Key findings and metrics
- **Facility Analysis**: Statistics and rankings
- **Risk Assessment**: Risk matrix with categorization
- **Export Options**: CSV, Excel, and JSON formats

## 🎨 Visual Features

- **Color-Coded Risk Levels**:
  - 🔴 Red: Critical/High Risk
  - 🟡 Yellow: Warning/Medium Risk
  - 🟢 Green: Normal/Low Risk
  - 🔵 Blue: Natural Events

- **Interactive Charts**: Hover for details, zoom, pan, and download
- **Responsive Design**: Optimized for various screen sizes
- **Professional Styling**: Gradient cards, modern UI elements

## 📁 Project Structure

```
THERMOINTEL_MVP/
├── app.py                          # Main enhanced dashboard
├── streamlit_app.py               # Legacy single-page version
├── pages/                         # Dashboard page modules
│   ├── __init__.py
│   ├── dashboard.py              # Main overview page
│   ├── facility_analysis.py      # Facility-level analysis
│   ├── event_analysis.py         # Event clustering & patterns
│   ├── insights.py               # AI insights & alerts
│   └── reports.py                # Report generation
├── backend/
│   ├── pipeline.py               # Data processing pipeline
│   ├── ingestion/               # FIRMS data ingestion
│   ├── event_formation/         # HDBSCAN clustering
│   ├── anomaly_detection/       # Isolation Forest
│   ├── classification/          # XGBoost & prototype rules
│   └── geospatial/             # Facility enrichment
├── data/
│   └── demo_facilities.csv      # Sample facility data
├── requirements.txt             # Python dependencies
└── README.md                    # This file
```

## 🔧 Technical Stack

- **Frontend**: Streamlit, Plotly, Folium
- **Backend**: Python, Pandas, NumPy
- **Machine Learning**: scikit-learn, HDBSCAN, XGBoost
- **Visualization**: Plotly Express, Plotly Graph Objects
- **Geospatial**: Folium, streamlit-folium
- **Export**: openpyxl (Excel), CSV, JSON

## 📦 Dependencies

All dependencies are listed in `requirements.txt`:
- streamlit: Web dashboard framework
- pandas & numpy: Data manipulation
- scikit-learn: Machine learning utilities
- hdbscan: Event clustering
- xgboost: Classification model
- plotly: Interactive visualizations
- folium & streamlit-folium: GIS mapping
- streamlit-option-menu: Navigation menu
- openpyxl: Excel export
- scipy: Scientific computing

## 🔐 Data Privacy

- All processing happens locally
- No data transmitted to external servers
- Offline-capable with demo data
- Facility data remains confidential

## 📝 Usage Notes

- **Demo Data**: Sample FIRMS and facility data included
- **Custom Data**: Upload your own FIRMS CSV and facility context
- **Export Reports**: Generate professional reports for stakeholders
- **Alert System**: Real-time monitoring of high-risk events

## 🎯 Use Cases

1. **Industrial Monitoring**: Track thermal events near industrial facilities
2. **Risk Assessment**: Identify high-risk events and facilities
3. **Anomaly Detection**: Flag unusual thermal patterns
4. **Compliance Reporting**: Generate professional reports for regulators
5. **Predictive Analysis**: Identify trends and patterns

## 🚦 Alert Levels

- **🔴 Critical**: Industrial fire near facility (<2km, high FRP)
- **🟡 Warning**: Anomalous activity near facility (<5km)
- **🟢 Normal**: Persistent industrial thermal sources
- **🔵 Info**: Natural or other thermal events

## 📊 Key Metrics

- **Fire Radiative Power (FRP)**: Thermal intensity in MW
- **Duration**: Event duration in hours
- **Persistence**: Number of days with detections
- **Spatial Spread**: Geographic extent in kilometers
- **Anomaly Score**: Statistical deviation from baseline
- **Confidence Score**: Classification confidence percentage

## 🤝 Contributing

This is an MVP (Minimum Viable Product) for demonstration purposes. For production deployment:
- Implement user authentication
- Add database integration
- Set up automated data ingestion
- Deploy with proper security measures
- Add API layer for integration

## 📄 License

Copyright © 2024 ThermoIntel MVP

## 🙏 Acknowledgments

- NASA FIRMS for thermal detection data
- OpenStreetMap for facility context
- Streamlit for dashboard framework
- HDBSCAN for clustering algorithm

---

**Built with ❤️ for Industrial Thermal Intelligence**
