# THERMOINTEL MVP - User Guide

## 📖 Table of Contents

1. [Getting Started](#getting-started)
2. [Dashboard Navigation](#dashboard-navigation)
3. [Features Overview](#features-overview)
4. [Step-by-Step Workflows](#step-by-step-workflows)
5. [Understanding the Data](#understanding-the-data)
6. [Exporting Reports](#exporting-reports)
7. [Troubleshooting](#troubleshooting)

---

## 🚀 Getting Started

### Prerequisites
- Python 3.8 or higher
- pip package manager
- Web browser (Chrome, Firefox, or Edge recommended)

### Installation Steps

1. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Launch the Application**
   
   **Option 1: Enhanced Dashboard (Recommended)**
   ```bash
   streamlit run app.py
   ```
   Or double-click `run_enhanced.bat`
   
   **Option 2: Legacy Dashboard**
   ```bash
   streamlit run streamlit_app.py
   ```
   Or double-click `run.bat`

3. **Access the Dashboard**
   - The application will open automatically in your browser
   - Default URL: http://localhost:8501
   - If it doesn't open, manually navigate to the URL shown in the terminal

---

## 🧭 Dashboard Navigation

### Main Menu
The enhanced dashboard features a sidebar menu with 5 main sections:

1. **📊 Dashboard**: Overview and GIS map
2. **🏭 Facility Analysis**: Facility-level insights
3. **📈 Event Analysis**: Clustering and patterns
4. **💡 Insights & Alerts**: AI recommendations
5. **📄 Reports**: Report generation and export

### Sidebar Controls

**Data Upload Section:**
- **Upload NASA FIRMS CSV**: Your thermal detection data
- **Upload Facility Data**: Optional context (CSV, GeoJSON, or JSON)
- **Process Data Button**: Click to run the analysis pipeline

**Data Status:**
- Shows the number of events, detections, and facilities loaded
- Updates automatically after processing

---

## 🎯 Features Overview

### 1. Dashboard Page

**Key Components:**

**Top Metrics Bar**
- Thermal Detections: Total number of individual thermal detections
- Thermal Events: Grouped clusters of related detections
- Potential Industrial Fires: High-risk events
- Persistent Sources: Ongoing thermal activity

**Interactive GIS Map**
- **Red Markers**: Potential industrial fires
- **Orange Markers**: Persistent thermal sources
- **Blue Markers**: Natural/other thermal events
- **Gray Icons**: Industrial facilities
- Click markers for detailed event information

**Quick Statistics Panel**
- Anomaly detection breakdown
- Classification distribution
- Facility proximity analysis
- Top facilities by event count

**Visualization Charts**
- Event classification pie chart
- Fire Radiative Power (FRP) distribution
- Event duration analysis
- Distance to facility scatter plot

**Critical Alerts Section**
- Real-time high-risk notifications
- Color-coded by severity:
  - 🔴 Critical: Immediate action required
  - 🟡 Warning: Monitor closely
  - 🟢 Normal: Routine monitoring

---

### 2. Facility Analysis Page

**Purpose:** Deep dive into facility-level metrics and risk assessment

**Key Features:**

**Facility Selector**
- Dropdown to select specific facility or view all
- Filters all charts and statistics automatically

**Risk Ranking Table**
- Color-coded risk scores:
  - Red: High risk (>50)
  - Yellow: Medium risk (20-50)
  - Green: Low risk (<20)
- Sortable columns
- Includes: events, fires, FRP, distance, anomalies

**Facility-Specific Charts** (when facility selected)
- Event classification breakdown
- Anomaly detection distribution
- FRP distribution histogram
- Event duration histogram
- Temporal trend line (daily detections)
- Spatial density heatmap
- Detailed event table

**Facility Comparison Charts** (all facilities view)
- Top 10 facilities by event count
- Event distribution by facility type
- Facility risk heatmap
- Distance vs FRP scatter analysis

---

### 3. Event Analysis Page

**Purpose:** Advanced clustering analysis and pattern detection

**Filter Options (Sidebar)**
- Classification filter (multi-select)
- Anomaly status filter
- Minimum FRP slider
- Shows filtered event count

**Tab 1: Cluster Visualization**
- **3D Event Distribution**: Latitude, longitude, and FRP in 3D space
- **Feature Space Plot**: FRP vs Duration with size by detections
- **Hierarchical Dendrogram**: Tree-based similarity visualization (Ward method)

**Tab 2: Statistical Analysis**
- **Feature Distributions**: Histogram with box plot overlay
- **Classification Comparison**: Box plots by classification
- **Correlation Matrix**: Heatmap of feature relationships
- **Statistical Summary**: Mean, std, min, max, quartiles

**Tab 3: Temporal Patterns**
- **Daily Detection Trend**: Line chart over time
- **Hourly Pattern**: Bar chart of detections by hour
- **Day of Week Analysis**: Weekly pattern visualization
- **Day vs Hour Heatmap**: 2D temporal density

**Tab 4: Spatial Analysis**
- **Spatial Density Heatmap**: Geographic concentration
- **Event Distribution Map**: Scatter map with classification colors
- **Spatial Metrics**: Center points and spread statistics
- **Spatial Spread Distribution**: Violin plot by classification

---

### 4. Insights & Alerts Page

**Purpose:** AI-driven recommendations and alert management

**Priority Alerts Section**

**🔴 Critical Alerts**
- Potential industrial fires near facilities (<2 km)
- High FRP (>75th percentile)
- Immediate investigation recommended
- Shows: location, facility, FRP, duration, confidence

**🟡 Warning Alerts**
- Anomalous thermal patterns
- Within 5 km of facilities
- Monitor closely
- Shows: anomaly score, facility, distance

**🟢 Routine Monitoring**
- Persistent industrial thermal sources
- Normal operational patterns
- Continue routine monitoring

**AI-Driven Insights**

**Pattern Analysis**
- Most active facilities table
- Risk level distribution pie chart
- Facility type breakdown

**Recommendations Panel**
- Dynamic action items based on data
- Priority-coded suggestions
- Facility-specific monitoring advice
- System-wide recommendations

**Trend Analysis**
- FRP trends by classification
- Facility proximity statistics
- Box plots and violin plots for comparison

**Predictive Insights**
- High-risk facilities ranking
- Event characteristic metrics
- Anomaly statistics and trends

**Export Options**
- Export critical alerts to CSV
- Export warning alerts to CSV
- Export all insights to CSV

---

### 5. Reports Page

**Purpose:** Professional report generation and data export

**Report Configuration**
- **Report Title**: Customizable report name
- **Author/Organization**: Your name or company
- **Report Date**: Date selector
- **Report Type**: Executive Summary, Detailed Analysis, Facility-Specific, or Custom

**Data Filters**
- **Event Classification**: Multi-select filter
- **Facilities**: Select specific facilities or all
- **Anomalies Only**: Toggle for anomaly-focused reports
- Shows filtered event count

**Report Preview Sections**

1. **Executive Summary**
   - Report metadata (title, date, author)
   - Key metrics (4 metric cards)
   - Key findings (5 bullet points)

2. **Facility Analysis**
   - Facility statistics table
   - Risk scores and rankings
   - Top 10 facilities chart

3. **Event Classification Analysis**
   - Classification distribution pie chart
   - Statistics by classification
   - FRP and duration distributions

4. **Risk Assessment**
   - Risk matrix (Critical/High/Medium/Low)
   - Color-coded risk counts
   - Critical event details table

5. **Detailed Event Data**
   - Full event table with all metrics
   - Sortable and filterable

**Export Options**

**📄 CSV Export**
- Events CSV: All event data
- Detections CSV: Raw detection data

**📊 Excel Export**
- Multi-sheet workbook:
  - Events sheet
  - Facility Analysis sheet
  - Risk Summary sheet
- Formatted and ready for stakeholder distribution

**📋 JSON Export**
- Machine-readable format
- For API integration or further processing

---

## 🔄 Step-by-Step Workflows

### Workflow 1: Initial Data Analysis

1. **Upload Data**
   - Click "Browse files" under "Upload NASA FIRMS CSV"
   - Select your FIRMS data file
   - Optionally upload facility context

2. **Process Data**
   - Click "🔄 Process Data" button
   - Wait for confirmation message

3. **Review Dashboard**
   - Check key metrics at the top
   - Explore the interactive map
   - Read critical alerts

4. **Investigate Facilities**
   - Navigate to "Facility Analysis"
   - Review risk ranking table
   - Select high-risk facilities for details

### Workflow 2: Risk Assessment

1. **Check Insights & Alerts**
   - Navigate to "Insights & Alerts"
   - Review critical alerts (🔴)
   - Review warning alerts (🟡)

2. **Analyze Patterns**
   - Check "Most Active Facilities"
   - Review "Risk Level Distribution"
   - Read AI recommendations

3. **Facility Deep Dive**
   - Go to "Facility Analysis"
   - Select flagged facility from dropdown
   - Review temporal trends
   - Check spatial distribution

4. **Document Findings**
   - Navigate to "Reports"
   - Configure report settings
   - Preview report sections
   - Export as Excel or PDF

### Workflow 3: Event Investigation

1. **Filter Events**
   - Navigate to "Event Analysis"
   - Use sidebar filters:
     - Select classifications of interest
     - Set minimum FRP threshold

2. **Explore Clustering**
   - Tab 1: View 3D distribution
   - Identify spatial clusters
   - Check hierarchical relationships

3. **Statistical Analysis**
   - Tab 2: Review distributions
   - Check correlation matrix
   - Compare classifications

4. **Temporal Patterns**
   - Tab 3: View daily trends
   - Identify hourly patterns
   - Check weekly cycles

5. **Spatial Analysis**
   - Tab 4: Review density heatmap
   - Check spatial spread metrics

### Workflow 4: Reporting to Stakeholders

1. **Configure Report**
   - Navigate to "Reports"
   - Enter report title and author
   - Select report date
   - Choose report type

2. **Apply Filters**
   - Select relevant classifications
   - Choose facilities to include
   - Toggle anomalies if needed

3. **Review Preview**
   - Expand all sections
   - Check executive summary
   - Verify facility analysis
   - Review risk assessment

4. **Export**
   - Choose format:
     - CSV for data analysis
     - Excel for stakeholder distribution
     - JSON for system integration
   - Click export button
   - Download file

---

## 📊 Understanding the Data

### Event Metrics Explained

**Fire Radiative Power (FRP)**
- Measurement: Megawatts (MW)
- Indicates thermal intensity
- Higher values = more intense heat
- Typical industrial: 10-100 MW
- Major fires: >100 MW

**Duration**
- Measurement: Hours
- Time span between first and last detection
- Persistent sources: >24 hours
- Acute events: <12 hours

**Persistence**
- Measurement: Days
- Number of calendar days with detections
- Indicates consistency
- Industrial operations: multi-day persistence

**Spatial Spread**
- Measurement: Kilometers
- Geographic extent of event
- Calculated from detection centroid
- Larger = more dispersed

**Detections**
- Count of individual thermal observations
- Multiple detections = event
- More detections = higher confidence

**Anomaly Score**
- Range: 0 to 1 (lower = more anomalous)
- Isolation Forest algorithm
- Compares to dataset baseline
- <0.1 typically flagged as anomaly

**Confidence Score**
- Range: 0% to 100%
- Classification confidence
- Prototype rule-based
- Higher = more confident classification

### Classification Types

**Potential Industrial Fire** (Red)
- Near industrial facility (<5 km)
- High FRP or long duration
- Requires investigation
- May indicate emergency

**Persistent Industrial Thermal Source** (Orange)
- Consistent thermal signature
- Multi-day persistence
- Near industrial facility
- Likely normal operations

**Natural / Other Thermal Event** (Blue)
- Distant from facilities (>5 km)
- Or atypical characteristics
- May be wildfire or agricultural burning

### Risk Levels

**Critical** 🔴
- Industrial fire + close to facility (<2 km) + high FRP
- Immediate action required

**High** 🟡
- Industrial fire OR (anomaly + near facility)
- Monitor closely

**Medium** 🟠
- Persistent thermal source
- Routine monitoring

**Low** 🟢
- Natural/other events
- Low priority

---

## 📥 Exporting Reports

### CSV Export
**Best for:** Data analysis, Excel manipulation
**Contains:** Raw data in comma-separated format
**Use cases:**
- Further statistical analysis
- Integration with other tools
- Custom visualizations

### Excel Export
**Best for:** Stakeholder distribution, professional reports
**Contains:** Multiple sheets with formatted data
**Sheets:**
- Events: All event data
- Facility Analysis: Facility statistics
- Risk Summary: Risk categorization
**Use cases:**
- Executive presentations
- Regulatory compliance
- Team sharing

### JSON Export
**Best for:** API integration, programmatic access
**Contains:** Machine-readable structured data
**Use cases:**
- System integration
- Database import
- Custom applications

---

## 🔧 Troubleshooting

### Application Won't Start

**Problem:** `streamlit: command not found`
**Solution:** 
```bash
pip install streamlit
```

**Problem:** Port already in use
**Solution:**
```bash
streamlit run app.py --server.port 8502
```

**Problem:** Browser doesn't open automatically
**Solution:** Manually navigate to http://localhost:8501

### Data Upload Issues

**Problem:** "Error processing data"
**Solution:** 
- Verify CSV format matches FIRMS structure
- Check for required columns: latitude, longitude, brightness, frp, confidence
- Ensure no corrupted rows

**Problem:** Facility upload fails
**Solution:**
- For CSV: Ensure columns are named: facility, latitude, longitude, facility_type
- For GeoJSON: Ensure valid GeoJSON format with Point features

### Performance Issues

**Problem:** Slow processing with large datasets
**Solution:**
- Process data once, then use filters
- Consider sampling large datasets
- Close other browser tabs

**Problem:** Charts not loading
**Solution:**
- Refresh the page
- Check browser console for errors
- Clear browser cache

### Visualization Issues

**Problem:** Map not displaying
**Solution:**
- Check internet connection (for basemap tiles)
- Try different basemap style
- Refresh page

**Problem:** Charts showing errors
**Solution:**
- Verify data was processed successfully
- Check for NaN values in data
- Re-process data

### Export Issues

**Problem:** Excel export fails
**Solution:**
```bash
pip install openpyxl
```

**Problem:** Download doesn't start
**Solution:**
- Check browser download settings
- Allow pop-ups for localhost
- Try different browser

---

## 💡 Best Practices

1. **Always process data before navigating**
   - Upload data
   - Click "Process Data"
   - Wait for confirmation

2. **Use filters to focus analysis**
   - Start broad, then narrow down
   - Filter by classification first
   - Then filter by facility or risk level

3. **Export regularly**
   - Save reports for historical comparison
   - Document critical alerts
   - Archive investigation findings

4. **Check multiple views**
   - Don't rely on single perspective
   - Cross-reference map, charts, and tables
   - Verify alerts with statistical analysis

5. **Understand limitations**
   - Prototype rules, not validated models
   - Demo data is synthetic
   - Anomaly detection is relative to upload

---

## 📞 Support

For questions, issues, or feature requests:
- Review this user guide
- Check the README.md
- Examine code comments in source files

---

**Version:** 1.0.0 Enhanced  
**Last Updated:** 2024  
**Author:** ThermoIntel MVP Team
