@echo off
echo ========================================
echo  THERMOINTEL MVP - Enhanced Dashboard
echo ========================================
echo.
echo Starting the enhanced multi-page dashboard...
echo.
streamlit run app.py
pause
