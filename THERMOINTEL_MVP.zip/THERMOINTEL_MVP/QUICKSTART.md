# 🚀 THERMOINTEL - Quick Start Guide

## ⚡ 5-Minute Setup

### Step 1: Install Dependencies (2 minutes)
```bash
pip install -r requirements.txt
```

### Step 2: Launch Dashboard (1 minute)
```bash
streamlit run app.py
```
Or double-click **`run_enhanced.bat`**

### Step 3: Upload & Process (1 minute)
1. Click **"Browse files"** in the sidebar
2. Select your FIRMS CSV (or skip to use demo data)
3. Click **"🔄 Process Data"**
4. Wait for success message

### Step 4: Explore (1 minute)
Navigate through the dashboard sections:
- **📊 Dashboard**: See the overview
- **🏭 Facility Analysis**: Check facility risks
- **💡 Insights & Alerts**: Review AI recommendations

---

## 🎯 Key Actions

### View Critical Alerts
1. Go to **Dashboard** page
2. Scroll to **"🚨 Critical Alerts"** section
3. Review red alert cards

### Analyze a Facility
1. Go to **Facility Analysis** page
2. Select facility from dropdown
3. View charts and metrics

### Generate a Report
1. Go to **Reports** page
2. Configure report settings
3. Click **"Export Full Report (Excel)"**
4. Download the file

---

## 📊 Understanding the Dashboard

### Color Codes
- 🔴 **Red**: Critical/High Risk - Immediate action
- 🟡 **Yellow**: Warning/Medium Risk - Monitor closely
- 🟢 **Green**: Normal/Low Risk - Routine monitoring
- 🔵 **Blue**: Natural events - Low priority

### Key Metrics
- **FRP**: Fire Radiative Power (MW) - Heat intensity
- **Duration**: How long the event lasted (hours)
- **Persistence**: Number of days detected
- **Distance**: Distance to nearest facility (km)

---

## 🔥 Common Use Cases

### Use Case 1: Daily Monitoring
1. Upload today's FIRMS data
2. Check Dashboard for critical alerts
3. Review Insights & Alerts page
4. Export critical alerts CSV

### Use Case 2: Facility Audit
1. Process historical FIRMS data
2. Go to Facility Analysis
3. Select facility from dropdown
4. Review risk score and trends
5. Export facility report

### Use Case 3: Incident Investigation
1. Upload incident period data
2. Go to Event Analysis
3. Filter by classification and FRP
4. Check temporal patterns
5. Review spatial distribution
6. Generate detailed report

---

## 💡 Pro Tips

✅ **Upload facility data** for better context (CSV with: facility, latitude, longitude, facility_type)

✅ **Use filters** in Event Analysis to focus on specific event types

✅ **Export regularly** - Download reports for record-keeping

✅ **Check multiple views** - Cross-reference map, charts, and tables

✅ **Review anomalies** - Unusual patterns may indicate issues

---

## ❓ Troubleshooting

**Problem**: Map not showing
**Solution**: Check internet connection for basemap tiles

**Problem**: "hdbscan not found"
**Solution**: `pip install hdbscan`

**Problem**: Processing takes too long
**Solution**: Use smaller data samples or wait for completion

**Problem**: Export fails
**Solution**: `pip install openpyxl` for Excel export

---

## 📚 Next Steps

- Read the full **USER_GUIDE.md** for detailed instructions
- Check **README.md** for technical details
- Explore all dashboard pages
- Customize report templates
- Integrate with your workflow

---

## 🎉 You're Ready!

Your THERMOINTEL dashboard is now running. Start exploring your thermal intelligence data!

**Need help?** Check USER_GUIDE.md for comprehensive documentation.

---

**Version**: 1.0 Enhanced  
**Support**: See documentation files in project root
