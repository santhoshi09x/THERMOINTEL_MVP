"""Enhanced THERMOINTEL Dashboard with Analytics, Graphs, and Reporting."""

import pandas as pd
import streamlit as st
from streamlit_option_menu import option_menu

# Page configuration
st.set_page_config(
    page_title="THERMOINTEL - Industrial Thermal Intelligence",
    page_icon="🔥",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for professional styling
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        padding: 1rem 0;
        border-bottom: 3px solid #ff7f0e;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .metric-value {
        font-size: 2.5rem;
        font-weight: bold;
        margin: 0.5rem 0;
    }
    .metric-label {
        font-size: 1rem;
        opacity: 0.9;
    }
    .alert-card {
        background: #ff4444;
        padding: 1rem;
        border-radius: 8px;
        color: white;
        margin: 0.5rem 0;
    }
    .warning-card {
        background: #ffaa00;
        padding: 1rem;
        border-radius: 8px;
        color: white;
        margin: 0.5rem 0;
    }
    .info-card {
        background: #00C851;
        padding: 1rem;
        border-radius: 8px;
        color: white;
        margin: 0.5rem 0;
    }
    .stTabs [data-baseweb="tab-list"] {
        gap: 24px;
    }
    .stTabs [data-baseweb="tab"] {
        height: 50px;
        padding: 0 24px;
        background-color: #f0f2f6;
        border-radius: 8px 8px 0 0;
    }
    .stTabs [aria-selected="true"] {
        background-color: #1f77b4;
        color: white;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'events' not in st.session_state:
    st.session_state.events = None
if 'detections' not in st.session_state:
    st.session_state.detections = None
if 'facilities' not in st.session_state:
    st.session_state.facilities = None

# Import pages
from pages import dashboard, facility_analysis, event_analysis, reports, insights

# Sidebar navigation
with st.sidebar:
    st.markdown("### 🔥 THERMOINTEL")
    st.markdown("*Event-Centric AI for Industrial Thermal Intelligence*")
    st.markdown("---")
    
    selected = option_menu(
        menu_title="Navigation",
        options=["Dashboard", "Facility Analysis", "Event Analysis", "Insights & Alerts", "Reports"],
        icons=["speedometer2", "building", "diagram-3", "lightbulb", "file-earmark-text"],
        menu_icon="cast",
        default_index=0,
    )
    
    st.markdown("---")
    
    # Data upload section
    st.markdown("### 📁 Data Upload")
    uploaded = st.file_uploader("Upload NASA FIRMS CSV", type=["csv"], key="firms_upload")
    facility_upload = st.file_uploader(
        "Upload Facility Data (optional)",
        type=["csv", "geojson", "json"],
        help="CSV columns: facility, latitude, longitude, facility_type",
        key="facility_upload"
    )
    
    # Process data
    if st.button("🔄 Process Data", use_container_width=True):
        from backend.pipeline import process_firms
        
        with st.spinner("Processing thermal data..."):
            try:
                if uploaded:
                    raw_detections = pd.read_csv(uploaded)
                else:
                    raw_detections = pd.read_csv("sample_firms.csv")
                
                events, detections, facilities = process_firms(raw_detections, facility_upload)
                
                st.session_state.events = events
                st.session_state.detections = detections
                st.session_state.facilities = facilities
                
                st.success("✅ Data processed successfully!")
            except Exception as e:
                st.error(f"❌ Error processing data: {str(e)}")
    
    # Show data status
    if st.session_state.events is not None:
        st.markdown("---")
        st.markdown("### 📊 Data Status")
        st.info(f"✅ {len(st.session_state.events)} events loaded")
        st.info(f"✅ {len(st.session_state.detections)} detections loaded")
        st.info(f"✅ {len(st.session_state.facilities)} facilities loaded")

# Main content area
if st.session_state.events is None:
    st.markdown('<div class="main-header">🔥 THERMOINTEL</div>', unsafe_allow_html=True)
    st.info("👈 Please upload FIRMS data and click 'Process Data' to begin analysis")
    
    # Show demo instructions
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("""
        ### Getting Started
        
        1. **Upload Data**: Use the sidebar to upload NASA FIRMS CSV data
        2. **Optional**: Upload facility context (CSV, GeoJSON, or JSON)
        3. **Process**: Click the "Process Data" button
        4. **Analyze**: Navigate through different views:
           - 📊 **Dashboard**: Overview and key metrics
           - 🏭 **Facility Analysis**: Facility-level insights
           - 📈 **Event Analysis**: Detailed event clustering and patterns
           - 💡 **Insights & Alerts**: AI-driven recommendations
           - 📄 **Reports**: Generate and export professional reports
        
        ### Features
        - Real-time thermal event detection and clustering
        - Facility-proximity analysis
        - Anomaly detection using Isolation Forest
        - AI-powered classification
        - Interactive maps and visualizations
        - Exportable reports (PDF, CSV, Excel)
        """)
else:
    # Route to selected page
    if selected == "Dashboard":
        dashboard.show()
    elif selected == "Facility Analysis":
        facility_analysis.show()
    elif selected == "Event Analysis":
        event_analysis.show()
    elif selected == "Insights & Alerts":
        insights.show()
    elif selected == "Reports":
        reports.show()
