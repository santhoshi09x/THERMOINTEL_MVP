"""Visualization helper functions for consistent styling and formatting."""

import plotly.graph_objects as go
import plotly.express as px


# Color palettes
CLASSIFICATION_COLORS = {
    "Potential Industrial Fire": "#ff4444",
    "Persistent Industrial Thermal Source": "#ffaa00",
    "Natural / Other Thermal Event": "#4444ff"
}

RISK_COLORS = {
    "Critical": "#ff4444",
    "High": "#ff9944",
    "Medium": "#ffaa00",
    "Low": "#00C851"
}

ANOMALY_COLORS = {
    "Anomaly": "#ff4444",
    "Normal": "#00C851"
}


def get_classification_color(classification):
    """Get color for event classification."""
    return CLASSIFICATION_COLORS.get(classification, "#999999")


def get_risk_color(risk_level):
    """Get color for risk level."""
    return RISK_COLORS.get(risk_level, "#999999")


def format_metric_card(value, label, color_start="#667eea", color_end="#764ba2"):
    """Generate HTML for a metric card with gradient background."""
    return f"""
    <div style="background: linear-gradient(135deg, {color_start} 0%, {color_end} 100%); 
                padding: 1.5rem; border-radius: 10px; color: white; text-align: center;
                box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
        <div style="font-size: 0.9rem; opacity: 0.9;">{label}</div>
        <div style="font-size: 2.5rem; font-weight: bold; margin: 0.5rem 0;">{value}</div>
    </div>
    """


def format_alert_card(title, content, alert_type="critical"):
    """Generate HTML for an alert card."""
    color_map = {
        "critical": "#ff4444",
        "warning": "#ffaa00",
        "info": "#00C851"
    }
    
    bg_color = color_map.get(alert_type, "#999999")
    
    return f"""
    <div style="background: {bg_color}; padding: 1rem; border-radius: 8px; 
                color: white; margin: 0.5rem 0;">
        <h4 style="margin: 0 0 0.5rem 0;">{title}</h4>
        <div>{content}</div>
    </div>
    """


def create_custom_legend(categories, colors):
    """Create a custom legend HTML for maps."""
    legend_items = ""
    for category, color in zip(categories, colors):
        legend_items += f'<p style="margin: 3px;"><i class="fa fa-circle" style="color:{color}"></i> {category}</p>'
    
    return f"""
    <div style="position: fixed; bottom: 50px; left: 50px; width: 220px; 
                background-color: white; border:2px solid grey; z-index:9999; font-size:14px;
                padding: 10px; border-radius: 5px;">
        <p style="margin-bottom: 5px;"><b>Legend</b></p>
        {legend_items}
    </div>
    """


def apply_theme_to_figure(fig, title=None, height=400):
    """Apply consistent theme to Plotly figures."""
    fig.update_layout(
        title=title,
        height=height,
        plot_bgcolor='rgba(0,0,0,0)',
        paper_bgcolor='rgba(0,0,0,0)',
        font=dict(family="Arial, sans-serif", size=12),
        margin=dict(l=40, r=40, t=40, b=40),
        hovermode='closest'
    )
    return fig


def create_gauge_chart(value, title, max_value=100, threshold_colors=None):
    """Create a gauge chart for metrics."""
    if threshold_colors is None:
        threshold_colors = [
            {"range": [0, 30], "color": "#00C851"},
            {"range": [30, 70], "color": "#ffaa00"},
            {"range": [70, 100], "color": "#ff4444"}
        ]
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=value,
        title={'text': title},
        gauge={
            'axis': {'range': [None, max_value]},
            'steps': threshold_colors,
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': value
            }
        }
    ))
    
    fig.update_layout(height=300)
    return fig


def create_risk_indicator(risk_score):
    """Create a visual risk level indicator."""
    if risk_score > 70:
        level = "Critical"
        color = "#ff4444"
        icon = "🔴"
    elif risk_score > 40:
        level = "High"
        color = "#ff9944"
        icon = "🟠"
    elif risk_score > 20:
        level = "Medium"
        color = "#ffaa00"
        icon = "🟡"
    else:
        level = "Low"
        color = "#00C851"
        icon = "🟢"
    
    return f"""
    <div style="display: inline-block; padding: 0.5rem 1rem; background: {color}; 
                color: white; border-radius: 20px; font-weight: bold;">
        {icon} {level} ({risk_score:.1f})
    </div>
    """


def format_event_popup(event):
    """Format event data for map popup."""
    history = "<br>".join(event.event_history) if hasattr(event, 'event_history') and event.event_history else "No timestamp data"
    
    return f"""
    <b>Event: {event.event_id}</b><br>
    <hr>
    <b>Classification:</b> {event.classification}<br>
    <b>Confidence:</b> {event.prototype_score:.0f}%<br>
    <br>
    <b>Thermal Metrics:</b><br>
    • Peak FRP: {event.peak_frp:.1f} MW<br>
    • Duration: {event.duration_hours:.1f} hours<br>
    • Persistence: {event.persistence_days} day(s)<br>
    • Detections: {event.detections}<br>
    • Spatial Spread: {event.spatial_spread_km:.2f} km<br>
    <br>
    <b>Facility Context:</b><br>
    • Nearest: {event.nearest_facility}<br>
    • Type: {event.facility_type}<br>
    • Distance: {event.distance_to_facility_km:.2f} km<br>
    <br>
    <b>Anomaly Analysis:</b><br>
    • Status: {event.anomaly_status}<br>
    • Score: {event.anomaly_score:.3f}<br>
    <br>
    <b>Detection History:</b><br>
    {history}
    """


def create_comparison_table(data, columns, highlight_column=None):
    """Create a formatted comparison table."""
    import pandas as pd
    
    df = pd.DataFrame(data)
    
    if highlight_column and highlight_column in df.columns:
        def highlight_max(s):
            is_max = s == s.max()
            return ['background-color: #ffff99' if v else '' for v in is_max]
        
        return df.style.apply(highlight_max, subset=[highlight_column])
    
    return df


def export_figure_as_html(fig, filename):
    """Export Plotly figure as standalone HTML."""
    fig.write_html(filename)
    return filename


# Chart templates
def create_bar_chart(data, x, y, color=None, title=None, orientation='v'):
    """Create a styled bar chart."""
    fig = px.bar(
        data,
        x=x,
        y=y,
        color=color,
        orientation=orientation,
        title=title,
        color_discrete_sequence=px.colors.qualitative.Set2
    )
    return apply_theme_to_figure(fig, title)


def create_line_chart(data, x, y, color=None, title=None, markers=True):
    """Create a styled line chart."""
    fig = px.line(
        data,
        x=x,
        y=y,
        color=color,
        markers=markers,
        title=title
    )
    return apply_theme_to_figure(fig, title)


def create_scatter_plot(data, x, y, color=None, size=None, title=None):
    """Create a styled scatter plot."""
    fig = px.scatter(
        data,
        x=x,
        y=y,
        color=color,
        size=size,
        title=title,
        color_discrete_sequence=px.colors.qualitative.Bold
    )
    return apply_theme_to_figure(fig, title)


def create_heatmap(data, x, y, z, title=None, colorscale='YlOrRd'):
    """Create a styled heatmap."""
    fig = px.imshow(
        data,
        x=x,
        y=y,
        color_continuous_scale=colorscale,
        title=title,
        aspect="auto"
    )
    return apply_theme_to_figure(fig, title)
