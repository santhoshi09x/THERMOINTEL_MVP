"""Utility functions for THERMOINTEL dashboard."""
