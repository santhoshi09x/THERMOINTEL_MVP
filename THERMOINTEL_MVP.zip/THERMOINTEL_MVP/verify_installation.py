"""
THERMOINTEL MVP - Installation Verification Script

Run this script to verify all dependencies are installed correctly.
"""

import sys

def check_import(package_name, import_name=None):
    """Check if a package can be imported."""
    if import_name is None:
        import_name = package_name
    
    try:
        __import__(import_name)
        print(f"✅ {package_name} - OK")
        return True
    except ImportError:
        print(f"❌ {package_name} - MISSING")
        return False

def main():
    """Verify all required packages."""
    print("=" * 60)
    print("THERMOINTEL MVP - Installation Verification")
    print("=" * 60)
    print()
    
    packages = [
        ("streamlit", "streamlit"),
        ("pandas", "pandas"),
        ("numpy", "numpy"),
        ("scikit-learn", "sklearn"),
        ("hdbscan", "hdbscan"),
        ("folium", "folium"),
        ("streamlit-folium", "streamlit_folium"),
        ("xgboost", "xgboost"),
        ("plotly", "plotly"),
        ("streamlit-option-menu", "streamlit_option_menu"),
        ("openpyxl", "openpyxl"),
        ("scipy", "scipy"),
    ]
    
    print("Checking required packages...")
    print()
    
    results = []
    for package_name, import_name in packages:
        results.append(check_import(package_name, import_name))
    
    print()
    print("=" * 60)
    
    success_count = sum(results)
    total_count = len(results)
    
    if success_count == total_count:
        print(f"✅ All {total_count} packages installed successfully!")
        print()
        print("You can now run the dashboard:")
        print("  > streamlit run app.py")
        print()
        print("Or double-click 'run_enhanced.bat'")
    else:
        missing_count = total_count - success_count
        print(f"⚠️  {missing_count} package(s) missing!")
        print()
        print("To install missing packages, run:")
        print("  > pip install -r requirements.txt")
    
    print("=" * 60)
    print()
    
    # Check Python version
    print("Python Version:")
    print(f"  {sys.version}")
    print()
    
    if sys.version_info < (3, 8):
        print("⚠️  Warning: Python 3.8 or higher recommended")
    else:
        print("✅ Python version OK")
    
    print()
    print("=" * 60)
    
    return success_count == total_count

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
